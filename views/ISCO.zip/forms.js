$(function(){
  var stateoptions;
    $.getJSON('states.json',function(result){
      $.each(result, function(i,state){
        stateoptions+=<"option value='"
        +state.code+
        "'>"
        +state.name+
        </option>";
      });
      $('#state').html(stateoptions);
    });

});

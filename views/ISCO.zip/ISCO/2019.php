<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
        <meta name="author" content="SemiColonWeb"/>
        <!-- Stylesheets
    ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css"/>
         <!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/ISCO_assets/css/bootstrap.css" type="text/css"/> -->
        <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/ISCO_assets/myfiles/style1.css"> -->
        <link href='<?php echo base_url();?>assets/ISCO_assets/myfiles/rotating-card.css' rel='stylesheet'/>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/ISCO_assets/myfiles/style.css" type="text/css"/>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/ISCO_assets/myfiles/dark.css" type="text/css"/>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/ISCO_assets/css/font-icons.css" type="text/css"/>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/ISCO_assets/css/animate.css" type="text/css"/>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/ISCO_assets/css/magnific-popup.css" type="text/css"/>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/ISCO_assets/myfiles/isco.css" type="text/css"/>
        <link href="https://fonts.googleapis.com/css?family=Lora|Abril+Fatface|Ropa+Sans|Cuprum|Encode+Sans+Condensed|Maven+Pro" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/ISCO_assets/css/responsive.css" type="text/css"/>
        <link rel="shortcut icon" href="<?php echo base_url();?>assets/ISCO_assets/intellify-img/logo3.png" type="image/png">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
        <!--[if lt IE 9]>
    	<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->
        <!-- External JavaScripts
    ============================================= -->
        <script type="text/javascript" src="<?php echo base_url();?>assets/ISCO_assets/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/ISCO_assets/js/plugins.js"></script>
  <!--  ============================================= -->
        <title>ISCO 2019 | Intellify</title>
        <style>
            .countdown-large .countdown-amount {
                font-size: 65px;
                color: #1f78ca;
            }

            .countdown-row {
                margin-top: 23%;
                margin-bottom: 10%
            }

            .heading-block h4 {
                font-size: 17px;
                font-weight: 700;
                color: #ff7f27;
            }

            .wifu li {
                font-size: 15px;
                padding: 7px;
            }

            .gr li {
                font-size: 15px;
                padding: 7px;
            }
            
            @media screen and (min-width: 768px) {
                .collapse {
                    height: 600px;
                }
            }
        </style>
    </head>
    <body class="stretched">
        <div id="header">
        </div>
        <section id="content" class="nobg nopadding" style="margin-top: 27px; margin-bottom: -54px">
            <!-- <div class="container clearfix center">
                <ul class="pagination ">
                    <li class="active  page-item">
                        <a class="page-link" href="<?php echo base_url() ?>ISCO/Year/2019" style="
                                font-size: calc(10px + 2vw);background-color: #FF7F27 !important; border-color: #FF7F27 !important;">
                            ISCO 2019 <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo base_url() ?>ISCO/Year/2018" style="
                                font-size: calc(10px + 2vw); color:black;">ISCO 2018</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo base_url() ?>ISCO/Year/2017" style="
                                font-size: calc(10px + 2vw); color:black;">ISCO 2017</a>
                    </li>
                </ul>
            </div> -->


<div class="container clearfix gr ">
    <div class="row clearfix common-height" style="border:#2a2c2e 5px solid; border-radius:40px;">
        <div class="col-md-6  center col-padding" style="background: url('<?php echo base_url();?>assets/ISCO_assets/intellify-img/coming soon.jpg') center center no-repeat; background-size: cover;height:550px;border-radius:36px 0px 0px 36px">
            <div>&nbsp;</div>
        </div>
        <div class="col-md-6  center col-padding" style="height:550px;     ;">
            <div id="countdown-ex3" class="countdown countdown-large"></div>
            <h1 style="font-size:70px;">TO GO</h1>
            <script>
                jQuery(document).ready(function($) {
                    var newDate = new Date(2019,7,6);
                    $('#countdown-ex1').countdown({
                        until: newDate
                    });
                    $('#countdown-ex2').countdown({
                        until: newDate
                    });
                    $('#countdown-ex3').countdown({
                        until: newDate
                    });
                });
            </script>
        </div>
    </div>
</div>
<div class="section nomargin notopborder nobg " style="
                            padding-bottom: 0px;">
    <div class="container clearfix ">
        <div id="myGroup" class="container">
            <div class="col_one_third center " data-animate="bounceIn">
                <button class="collapsible toggle">
                    <div>
                        <i class="icon-line-paper divcenter nobottommargin"></i>
                    </div>
                    <h5>Round 1</h5>
                </button>
                <div class="collapse">
                    <h4>INTRA SCHOOL OFFLINE ROUND</h4>
                    <strong>Dates :</strong>
                    6th August/ 9th August 2019 (as per school’s convenience)<br>
                    <strong>Venue :</strong>
                    Respective Schools<br>
                    <strong>Mode :</strong>
                    Offline (OMR based examination)<br>
                    <strong>Result :</strong>
                    30th September, 2019<br>
                    <strong>Top 5% participants from each school will qualify for Round 2.*</strong>
                    <br>
                    <strong>Skills to be tested :</strong>
                    <div style="margin-left:20px;  text-align:left">
                        <ul>
                       <li> Analytical Reasoning</li>
<li>Visual Skills</li>
<li>Spatial Skills</li>
<li>Quantitative Reasoning</li>
<li>Verbal Reasoning</li>


                        </ul>
                    </div>
                </div>
            </div>
            <div class="col_one_third center" data-animate="bounceIn">
                <button class="toggle collapsible">
                    <div>
                        <i class="icon-laptop2 divcenter nobottommargin"></i>
                    </div>
                    <h5>Round 2</h5>
                </button>
                <div class="collapse">
                    <h4>INTRA SCHOOL ONLINE ROUND</h4>
                    <strong>Dates :</strong>
                    14th October/22nd October 2019 (as per school’s convenience)<br>
                    <strong>Venue :</strong>
                    Respective Schools<br>
                    <strong>Mode :</strong>
                    Online<br>
                    <strong>Result :</strong>
                    15th November, 2019<br>
                    <strong>Top 20 participants from each level will qualify for Round 3.*</strong>
                    <br>
                    <strong>Skill to be tested : </strong>
                    <div style=" margin-left: 20px;  text-align:left">
                        <ul>
                            <li>Lateral Thinking</li>
                            <li>Inductive Reasoning</li>
                            <li>Processing Speed Index</li>
                            <li>Working Memory Index</li>
                            <li>Numerical Test</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col_one_third center col_last" data-animate="bounceIn">
                <button class="toggle collapsible">
                    <div>
                        <i class="icon-cogs divcenter nobottommargin"></i>
                    </div>
                    <h5>Round 3</h5>
                </button>
                <div class="collapse">
                    <h4>FINALE - INTERACTIVE EVENT</h4>
                    <strong>Date :</strong>
                    Mid-December<br>
                    <strong>Venue : </strong>
                    IIT Delhi<br>
                    <strong>Mode :</strong>
                    : Hands-On Round<br>
                    <strong>Workshop on Innovation & Creativity for all qualified students and teachers.
                                                                            Results and Prize Distribution Ceremony
                                                                            </strong>
                    <strong>Skills to be tested :</strong>
                    <div style=" margin-left: 20px; text-align:left">
                        <ul>
                            <li>Hands-On Skills</li>
                            <li>Presentation Skills</li>
                            <li>Team Coordination</li>
                            <li>Social and Environmental Skills</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('.toggle').click(function() {
        if (!$(this).next().hasClass('in')) {
            $(this).parent().children('.collapse.in').collapse('hide');
        }
        $(this).next().collapse('toggle');
    });
</script>
<div class="section  notopborder notopmargin">
    <div class="container clearfix wifu">
        <h1 style="color:#FF7F27">What's in It for You</h1>
        <ul>
            <li>Every student will be provided detailed analysis of his/her performance which will help in identifying the skills he/she is weak in.</li>
            <li>Every student will be given unique login ID on Intellify portal which will give them privileged access to all the content developed by Intellify, IIT Delhi and its partners.</li>
            <li>Every students participating in ISCO can avail benefits of our exclusive doubt solving platform ‘Solve’ App. </li>
            <li>Mentors from IIT Delhi will be provided to top performing students.</li>
            <li>Students will be provided them regular tests and material to build their skills as per their weaknesses assessed in the Olympiad throughout the next academic year! </li>
            <li>All teachers of the school can be a part of ‘Forum of Teachers’ organised by Intellify.</li>
        </ul>
        <div class-"row">
            <div class="col-md-2">
                <img src="<?php echo base_url();?>assets/ISCO_assets/intellify-img/gift.png" style="height:100px; width:100px; ">
            </div>
            <div class="col-md-8">
                <h1 style="margin-top: 24px; color: #4b76b6;">Prizes worth ₹5,00,000!</h1>
            </div>
        </div>
    </div>
    <div class="container clear-bottommargin clearfix">
        <div class="row topmargin-sm clearfix">
            <div class="col-md-3 bottommargin">
                <div class="heading-block nobottomborder" style="margin-bottom: 15px;">
                    <h4>Level 0 (Class V and VI)</h4>
                </div>
                <p>
                    Round 1 : Goodies and Certificates to Top 50<br>
                    Round 2 : DIY Kits, Merchandise and Medals to Top 10 and Free Trip to IIT Delhi for Top 20<br>
                    Round 3 : Smart Games, Merchandise and Trophies to Top 3 students and admission to Summer Boot camp 2019 <br>
                </p>
            </div>
            <div class="col-md-3 bottommargin">
                <div class="heading-block nobottomborder" style="margin-bottom: 15px;">
                    <h4>Level 1 (Class VII and VIII)</h4>
                </div>
                <p>
                    <strong>Round 1 :</strong>
                    Goodies and Certificates to Top 50<br>
                    <strong>Round 2 :</strong>
                    Study Kits, Merchandise and Medals to Top 10 and Free Trip to IIT Delhi for Top 20<br>
                    <strong>Round 3 :</strong>
                    Tablets, Merchandise and Trophies to Top 3 students and and admission to Summer Boot  camp 2019 <br>
                </p>
            </div>
            <div class="col-md-3 bottommargin">
                <div class="heading-block nobottomborder" style="margin-bottom: 15px;">
                    <h4>Level 2 (Class IX and X)</h4>
                </div>
                <p>
                    <strong>Round 1 :</strong>
                    Goodies and Certificates to Top 50 <br>
                    <strong>Round 2 :</strong>
                    Headsets, Merchandise and Medals to Top 10 and Free Trip to IIT Delhi for Top 20<br>
                    <strong>Round 3 :</strong>
                    Tablets, Merchandise and Trophies to Top 3 students and admission to Summer Boot camp 2019 <br>
                </p>
            </div>
            <div class="col-md-3 bottommargin">
                <div class="heading-block nobottomborder" style="margin-bottom: 15px;">
                    <h4>Level 3 (Class XI and XII)</h4>
                </div>
                <p>
                    <strong>Round 1 :</strong>
                    Goodies and Certificates to Top 50<br>
                    <strong>Round 2 :</strong>
                    Digital Watch, Merchandise and Medals to Top 10 and Free Trip to IIT Delhi for Top 20<br>
                    <strong>Round 3 :</strong>
                    Laptops, Merchandise and  Trophies to Top 3 students and admission to Summer Boot camp 2019 <br>
                </p>
            </div>
        </div>
    </div>
</div>
<div class="container clearfix gr bottommargin-lg">
    <div style="background-color:#bed0d6; padding:30px;border-radius:70px;text-align:center;">
        <h2>Guidelines and Rules For Schools and Students</h2>
        <ul style="list-style-position: inside;">
            <li>Students from Class 5 to 12 can participate.</li>
            <li>Medium of the test will be English/Hindi.</li>
            <li>There are four levels: Level 0 (Class 5 and 6), Level 1 (Class 7 and 8 ) , Level 2 ( Class 9 and 10) and Level 3.( Class 11 and 12). Students have to take part individually.</li>
            <li>Registration fees is Rs 150.</li>
            <li>Minimum number of students required from a school to participate is 30 across all standards (5-12).</li>
            <li>School will be allowed to keep a part of the fee per student to help in the organisation of the olympiad other than a fixed nominal amount. Round 1 would be held in the school of the participative student.
			<li>Round 2 may be an online olympiad which will also be given in the respective school/common centre in the city.</li>
            <li>Round 3 will be an interactive event where students will be required to perform various tasks and demonstrate their creativity in teams.</li>
            <li>Any school/student involving in any kind of unfair means while taking part in the olympiad would be barred and strict action would be taken against the student/ school.</li>
        </ul>
        <a style="background-color: #ff7f27 !important;" href="http://intellify.in/registration/" class="button button-3d button-xlarge button-rounded">Register here</a>
	<a style="background-color: #ff7f27 !important;" href="http://intellify.in/brochure.pdf" class="button button-3d button-xlarge button-rounded" download>Download Brochure</a>
    </div>
</div>

</section>
</body>
</html>

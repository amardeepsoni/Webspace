
<div class="container body">
    <div class="main_container">
        <?php $this->load->view(adminpath.'/sidebar') ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2><?php echo $heading; ?></h2>
                                <div class="container col-12 col-sm-6 col-md-6 site-form" >
                                    <table class="table table-dark" id="myTable">
                                        <thead>
                                        <tr>
                                            <th scope="col">S.N.</th>
                                            <th scope="col">Category ID</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Contact Person Name</th>
                                            <th scope="col">Contact Person Designation</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Alternate Mobile</th>
                                            <th scope="col">Address</th>
                                            <th scope="col">Registration Count</th>
                                            <th scope="col">School Type</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                        </thead>
                                    <?php
                                    $i=1;
                                        foreach ($schools as $school) {
                                            echo
                                                '<tbody>'.
                                                    '<tr>'.
                                                        '<td>'.$i.'</td>'.
                                                        '<td>'.$school->category_id.'</td>'.
                                                        '<td>'.$school->name.'</td>'.
                                                        '<td>'.$school->email.'</td>'.
                                                        '<td>'.$school->contact_person_name.'</td>'.
                                                        '<td>'.$school->contact_person_designation.'</td>'.
                                                        '<td>'.$school->mobile.'</td>'.
                                                        '<td>'.$school->mobile1.'</td>'.
                                                        '<td>'.$school->address.'</td>'.
                                                        '<td>'.$school->regcount.'</td>'.
                                                        '<td>'.$school->school_type.'</td>'.
                                                        '<td><a href="'.
                                                base_url().adminpath.'/ApproveRegistration/approveAll/'.$school->category_id.
                                                '">Approve All Students</a></td>'.
                                                    '</tr>'.
                                                '</tbody>';
                                            $i++;
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

    </div>
</div>

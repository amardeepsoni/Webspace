
<div class="container body">
    <div class="main_container">
        <?php $this->load->view(adminpath.'/sidebar') ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h3>Edit Exam</h3>
                                <div class="card-body">
                                    <h3><?php echo $quizDetails->title ?></h3>
                                    <input class="my-button" style="width:10em; height:3em;" type="button" name="answer" value="Add New Question" onclick="toggleDiv()" />
                                    <div id="getNoOfQuestions"  style="display:none;" >
                                        <form action="<?php echo base_url().adminpath.'/UpdateExam/addQuestion/' ?>" method="post" style="padding:2%; width:50%;">
                                            <input type="hidden" name="quizid" value="<?php echo $quizDetails->quizid ?>">
                                            <div class="form-group"><label for="mcq2">MCQ-2 Type Questions</label><input class="form-control" type="number" value=0 name="mcq2" placeholder="Enter number of MCQ (2 option) type questions" id="mcq2" /></div>
                                            <div class="form-group"><label for="mcq4">MCQ-4 Type Questions</label><input class="form-control" type="number" value=0 name="mcq4" placeholder="Enter number of MCQ (4 option) type questions" id="mcq4" /></div>
                                            <div class="form-group"><label for="integer">Integer Type Questions</label><input class="form-control" type="number" value=0 name="integer" placeholder="Enter number of integer type questions" id="integer" /></div>
                                            <button class="my-button" type="submit" style="width:6em; height:3em;">Submit</button>
                                        </form>
                                    </div>

                                    <?php
                                    $i = 0;
                                    foreach ($questionDetails as $ques) {
                                        echo  '<div class="media" style="padding:5%; width: 90%; word-wrap: break-word;">'.
                                              '<h4>Question Number. '.++$i.'</h4><br/><br/>'.
                                              '<p style="font-size:1.7em;">'.$ques->qnstext.'</p>'.
                                              '<a href = '.base_url().adminpath.'/UpdateExam/deleteQuestion/'.$quizDetails->quizid.'/'.$ques->quesid.'><button class="btn btn-danger" style="width:6em; height:4em; float:right;">Delete</button></a>';
                                              if($ques->options) {
                                                    echo '<br/><h5>Options</h5>';
                                                    echo '<ol style="font-size:1.5em;">';
                                                    foreach ($ques->options as $option) {
                                                        echo '<li>'.$option->text.'</li>';
                                                }
                                                    echo '</ol>';
                                                }
                                                echo '</div><br /><hr />';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

    </div>
</div>

<script type="text/javascript" >
    function toggleDiv() {
        if(document.getElementById('getNoOfQuestions').style.display ==="none")
            document.getElementById('getNoOfQuestions').style.display = "block";
        else
            document.getElementById('getNoOfQuestions').style.display = "none";
    }
</script>
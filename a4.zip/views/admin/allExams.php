
<div class="container body">
    <div class="main_container">
        <?php $this->load->view(adminpath.'/sidebar') ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h3><?php echo $heading; ?></h3>
                                    <table>
                                        <thead>
                                            <tr style="height:46px;">
                                                <th style="width:15%">Title</th>
                                                <th style="width:5%">Status</th>
                                                <th style="width:5%">Time Limit</th>
                                                <th style="width:5%">Skill</th>
                                                <th style="width:5%">Level</th>
                                                <th style="width:5%">Total Questions</th>
                                                <th style="width:5%">Belongs To</th>
                                                <th style="width:5%">Date Added</th>
                                                <th style="width:5%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                            if($allExams){
                                                foreach ($allExams as $exam) {

                                                    switch ($exam->belongs_to) {
                                                        case 0: $exam->belongs_to = 'Round 1';
                                                                break;
                                                        case 1: $exam->belongs_to = 'Round 2';
                                                                break;
                                                        case 2: $exam->belongs_to = 'Practice';
                                                                break;
                                                        default: $exam->belongs_to = null;
                                                    }

                                                    if($exam->status) {
                                                       echo '<tr style="height:46px; border-top: 1px solid #cacaca;">'.
                                                            '<td style="width:15%">'.$exam->title.'</td>'.
                                                            '<td style="width:5%">'.'Enabled'.'</td>'.
                                                            '<td style="width:5%">'.$exam->time.' min'.'</td>'.
                                                            '<td style="width:5%">'.$exam->skill_name.'</td>'.
                                                            '<td style="width:5%">'.$exam->level.'</td>'.
                                                            '<td style="width:5%">'.$exam->total.'</td>'.
                                                            '<td style="width:5%">'.$exam->belongs_to.'</td>'.
                                                            '<td style="width:5%">'.$exam->date.'</td>'.
                                                            '<td style="width:5%">'.
                                                                '<a href='.base_url().adminpath.'/EditExam/'.$exam->quizid.'>Edit  </a>'.
                                                                '<a href='.base_url().adminpath.'/UpdateExam/disable/'.$exam->quizid.'> Disable</a>'.
                                                                '<a href='.base_url().adminpath.'/UpdateExam/remove/'.$exam->quizid.'> Remove</a>'.'</td>'.
                                                            '</tr>';
                                                    }
                                                    else {
                                                        echo '<tr style="height:46px; border-top: 1px solid #cacaca;">'.
                                                            '<td style="width:15%">'.$exam->title.'</td>'.
                                                            '<td style="width:5%">'.'Disabled'.'</td>'.
                                                            '<td style="width:5%">'.$exam->time.' min'.'</td>'.
                                                            '<td style="width:5%">'.$exam->skill_name.'</td>'.
                                                            '<td style="width:5%">'.$exam->level.'</td>'.
                                                            '<td style="width:5%">'.$exam->total.'</td>'.
                                                            '<td style="width:5%">'.$exam->belongs_to.'</td>'.
                                                            '<td style="width:5%">'.$exam->date.'</td>'.
                                                            '<td style="width:5%">'.
                                                                '<a href='.base_url().adminpath.'/EditExam/'.$exam->quizid.'>Edit  </a>'.
                                                                '<a href='.base_url().adminpath.'/UpdateExam/enable/'.$exam->quizid.'> Enable</a>'.
                                                                '<a href='.base_url().adminpath.'/UpdateExam/remove/'.$exam->quizid.'> Remove</a>'.'</td>'.
                                                            '</tr>';
                                                    }


                                                 }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

    </div>
</div>

<div class="container body">
    <div class="main_container">
        <?php $this->load->view(adminpath.'/sidebar') ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel x_panel_file_upload">
                            <div class="x_title">
                               <div class="xyz" style="margin-left:40%;">
                                    <?php echo $error ?>
                                    <?php echo $success ?>
                                    <form action="<?php echo base_url().adminpath.'/UploadController/uploadData' ?>" method="post" enctype="multipart/form-data">
                                        <input class='custom-file-input' type='file' name='user_file'  />
                                        <div class='fileupload-btn'>
                                            <input name="Submit" type="submit" value="Upload">
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="x_content">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

    </div>
</div>
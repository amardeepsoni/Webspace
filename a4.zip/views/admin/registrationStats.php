<style>
        table{
    /* border-collapse: collapse; */
    width: 100%;
    border: none;
}
td{
    text-align: left;
    /* background: pink;
    color: white !important; */
    font-size: 15px;
    font-size: 800;
    border: none;
}
tr:nth-child(even) {
    background-color: #f2f2f2;
}
</style>
<div class="container body">
    <div class="main_container">
        <?php $this->load->view(adminpath.'/sidebar') ?>
        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h3>Registration Statistics</h3>
                            </div>
                        </div>
<!--                        --><?php //print_r($schools) ?>
                        <table>
                            <tr>
                                <th>School Name</th>
                                <th>Level 0</th>
                                <th>Level 1</th>
                                <th>Level 2</th>
                                <th>Level 3</th>
                            </tr>
                            <?php
                                foreach ($schools as $school) {
                                    echo
                                    '<tr>
                                        <td id="school_name_1">'.$school->name.'</td>
                                        <td id="level_0_'.$school->category_id.'"></td>
                                        <td id="level_1_'.$school->category_id.'"></td>
                                        <td id="level_2_'.$school->category_id.'"></td>
                                        <td id="level_3_'.$school->category_id.'"></td>
                                    </tr>'
                                    ;
                                }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->
        
    </div>
</div>


<script>


    <?php
    foreach ($schools as $school) {
        echo
            '$.ajax({'.
                'url: "http://intellifyflask-api.ap-south-1.elasticbeanstalk.com/api/GetParticipants/'.$school->category_id.'",'.
                'crossDomain: true,
                 cors: true,
                 dataType: "json",
                 type: "GET",
                 success: function(jsonObject, status) {
                 var data = jsonObject.participants;
                 $("#level_0_'.$school->category_id.'").html(data[0]);
                 $("#level_1_'.$school->category_id.'").html(data[1]);
                 $("#level_2_'.$school->category_id.'").html(data[2]);
                 $("#level_3_'.$school->category_id.'").html(data[3]);
                }
            });'
        ;
    }
    ?>


</script>
<div class="col-md-3 left_col">
  <div class="left_col scroll-view">
    <div class="navbar nav_title" style="border: 0;"> <a href="<?php echo base_url("admin"); ?>" class="site_title"><i class="fa fa-paw"></i> <span>Admin Panel</span></a> </div>
    <div class="clearfix"></div>
    
    <!-- sidebar menu -->
    
    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
      <div class="menu_section">
        <ul class="nav side-menu">
          <?php if($this->session->userdata['logged_in']['usertype']=='admin'){?>
          <li><a href="<?php echo base_url(adminpath.'/user');?>"><i class="fa fa-edit"></i> User Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/school');?>"><i class="fa fa-edit"></i>Add school Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/schoollavel');?>"><i class="fa fa-edit"></i> Round Level Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/studymaterial');?>"><i class="fa fa-edit"></i> Study Material Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/questiontype');?>"><i class="fa fa-edit"></i> Question Type Manager </a> </li>
          <?php echo allmenu(); ?>
          <?php } else {?>
          <?php echo adminmenu(); ?>
          <?php } ?>
          <li><a href="<?php echo base_url(adminpath.'/excelupload');?>"><i class="fa fa-edit"></i>Excel Upload </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/page');?>"><i class="fa fa-edit"></i>Page Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/teamcat');?>"><i class="fa fa-edit"></i>Team Cat Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/team');?>"><i class="fa fa-edit"></i>Team Manager </a> </li>
           <li><a href="<?php echo base_url(adminpath.'/testimonials');?>"><i class="fa fa-edit"></i> Client Testimonial Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/projects');?>"><i class="fa fa-edit"></i> Projects Manager </a> </li>
            <li><a href="<?php echo base_url(adminpath.'/addExam');?>"><i class="fa fa-edit"></i> Add Exam </a> </li>
            <li><a href="<?php echo base_url(adminpath.'/allExams');?>"><i class="fa fa-edit"></i> All Exams </a></li>


          
          
          
          
          <!--  <li><a href="<?php echo base_url(adminpath.'/setting');?>"><i class="fa fa-edit"></i> Comman Setting </a> </li>

          <li><a href="<?php echo base_url(adminpath.'/questiontype');?>"><i class="fa fa-edit"></i> Question Type </a> </li>


          <li><a href="<?php echo base_url(adminpath.'/category');?>"><i class="fa fa-edit"></i> Category Manager </a> </li>
          
          <li><a href="<?php echo base_url(adminpath.'/subject');?>"><i class="fa fa-edit"></i> Subject Manager </a> </li>
          

          <li><a href="<?php echo base_url(adminpath.'/chapter');?>"><i class="fa fa-edit"></i> Chapter Manager </a> </li>



          <li><a href="<?php echo base_url(adminpath.'/topic');?>"><i class="fa fa-edit"></i> Topic Manager </a> </li>

          <li><a href="<?php echo base_url(adminpath.'/questionbank');?>"><i class="fa fa-edit"></i> Question Bank Manager </a> </li>

          <li><a href="<?php echo base_url(adminpath.'/testpanel');?>"><i class="fa fa-edit"></i> Test Panel Manager </a> </li>
 --> 
          
          <!--\
            
          <li><a href="<?php echo base_url(adminpath.'/product');?>"><i class="fa fa-edit"></i> Add Test	  Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/paddques');?>"><i class="fa fa-edit"></i> Add Ques Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/photo');?>"><i class="fa fa-edit"></i> Gallery  Manager </a> </li>
              <li><a href="<?php echo base_url(adminpath.'/news');?>"><i class="fa fa-edit"></i> news Manager </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/blogcat');?>"><i class="fa fa-edit"></i> BLog Category </a> </li>
          <li><a href="<?php echo base_url(adminpath.'/blogscon');?>"><i class="fa fa-edit"></i> Blogs Manager </a> </li>-->
        </ul>
      </div>
    </div>
    
    <!-- /sidebar menu --> 
    
  </div>
</div>

<!-- top navigation -->

<div class="top_nav">
  <div class="nav_menu">
    <nav>
      <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
      <h2  class="pull-left" style="margin:17px 0 0">Intellify. </h2>
      <ul class="nav navbar-nav navbar-right">
        <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Admin <span class=" fa fa-angle-down"></span> </a>
          <ul class="dropdown-menu dropdown-usermenu pull-right">
            <li><a href="javascript:;"> Profile</a></li>
            <li><a href="<?php echo base_url(adminpath.'/login/logout'); ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
          </ul>
        </li>
      </ul>
    </nav>
  </div>
</div>

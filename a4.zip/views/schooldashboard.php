
<div id="page-content-wrapper">
  <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
    <div class="demo-parallax parallax section looking-photo nopadbot" data-stellar-background-ratio="0.5" style="background-image:url('<?php echo base_url();?>schoolassest/upload/demo_02.jpg');">
      <div class="page-title section nobg">
        <div class="container-fluid">
        <div class="clearfix">
          <div class="title-area pull-left">
            <!-- schoolinfo array has all the school details -->
            <h2><?php echo $schoolinfo->name; ?> <?php echo $heading; ?> </h2>
          </div>
        <!-- Section for Home/Dashboard link -->
        <div class="pull-right hidden-xs">
          <div class="bread">
            <ol class="breadcrumb">
              <?php if(isset($breadcrumbs)) {
                  $bi=0;
                  foreach($breadcrumbs as $rw) {
                  if($bi>0) {
                    echo "";
                  }
                  echo "<li><a href='".$rw['href']."'>".$rw['text']."</a></li>";
                $bi++;
              }
            }?>
            </ol>
          </div>
        </div>
        <!-- end Home/Dashboard link --> 
      </div>
    </div>
    <!-- end Menu -->
  </div>
  <!-- end-->
</div>
<!-- Section for main Content -->
<div class="section">
  <div class="container-fluid">
    <div class="row">
      <!-- Add Students section -->
      <div class="col-sm-6 col-md-4">
        <div class="addstudent bbm-1">
          <div class="addinner"><i class="fa fa-user topiyu"></i> <b> Add Students!</b> <a href="<?php echo base_url();?>addstudent"><i class="fa fa-angle-double-right pull-right"></i>Add </a> </div>
        </div>
      </div>
      <!-- end Add Students section -->
      <!-- View Student section -->
      <div class="col-sm-6 col-md-4">
        <div class="addstudent bbm-2">
          <div class="addinner countsert"><i class="fa fa-list topiyu"></i> <b> View Added Students
          <?php if($allstudents) {
            $abhy=1;  foreach ($allstudents as $value) {
            if($value['category_id']==$schoolinfo->category_id){?>
          <span>(<?php echo $abhy;?>)</span>
          <?php $abhy++;}}}?> 
          </b> <a href="<?php echo base_url();?>studentlist"><i class="fa fa-angle-double-right pull-right"></i>View </a> </div>
        </div>
      </div>
      <!-- end View Students section -->
      <!-- Study Materails section-->
      <div class="col-sm-6 col-md-4">
        <div class="addstudent bbm-3">
          <div class="addinner"><i class="fa fa-list topiyu"></i> <b> Study Materials</b> <a href="<?php echo base_url();?>studymaterials"><i class="fa fa-angle-double-right pull-right"></i>Add </a> </div>
        </div>
      </div>

      <!-- end Study Materails section -->
        <div class="col-sm-6 col-md-4">
            <div class="addstudent bbm-3">
                <div class="addinner"><i class="fa fa-list topiyu"></i> <b> Generate Attendance Sheet for Round-1 </b> <a href="<?php echo base_url();?>GenerateAttendanceSheet/round_1"> <i class="fa fa-angle-double-right pull-right"></i>Generate</a> </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="addstudent bbm-3">
                <div class="addinner"><i class="fa fa-list topiyu"></i> <b> Generate Attendance Sheet for Round-2 </b> <a href="<?php echo base_url();?>GenerateAttendanceSheet/round_2"> <i class="fa fa-angle-double-right pull-right"></i>Generate</a> </div>
            </div>
        </div>
    </div>
    <!-- end row-->
  </div>
  <!-- end container -->
</div>
<!-- end section -->

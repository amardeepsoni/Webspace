
<div class="banner-outer">
  <div class="banner-slider">
    <div class="slide1">
      <div class="container">
        <div class="content animated fadeInRight">
          <div class="fl-right">
            <h1 class="animated fadeInRight">Children must be taught <span class="animated fadeInRight"> How to think</span> </h1>
            <p class="animated fadeInRight">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <a href="#" class="btn animated fadeInRight">Know More <span class="icon-more-icon"></span></a> </div>
        </div>
      </div>
    </div>
    <div class="slide2">
      <div class="container">
        <div class="content">
          <h1 class="animated fadeInUp">Point of test</h1>
          <p class="animated fadeInUp">is not to judge the strength or weaknesses but to certify him/her as Ok or Fail.</p>
          <a href="#" class="btn animated fadeInUp">Know More <span class="icon-more-icon"></span></a> <a href="#" class="btn white animated fadeInUp hidden-xs">Take a Tour <span class="icon-more-icon"></span></a> </div>
      </div>
    </div>
    <div class="slide3">
      <div class="container">
        <div class="content animated fadeInLeft">
          <h1 class="animated fadeInLeft">Unless we fix</h1>
          <p class="animated fadeInLeft">Our school kids are going to look boring, uninspiring and dull.</p>
          <a href="#" class="btn animated fadeInLeft">Know More <span class="icon-more-icon"></span></a> </div>
      </div>
    </div>
  </div>
</div>

<!-- End Banner Carousel --> 

<!-- Start About Section -->

















<section class="about">
  <div class="container">
    <ul class="row our-links">
    
    
    
    <?php if($homeprojects) {?>


        <?php 
  foreach($homeprojects as $homeproject) { ?>
        
		 
		
      
    
    
    
    
    
    
      <li class="col-sm-4 apply-online clearfix equal-hight">
        <div class="icon"><img  src="<?php echo $homeproject['icon']; ?>" class="img-responsive" alt=""></div>
        <div class="detail">
          <h3><?php echo $homeproject['name']; ?></h3>
          <?php echo $homeproject['shortdescription']; ?>
          <a href="<?php echo base_url();?>projects#project<?php echo $homeproject['id']; ?>" class="more"><i class="fa fa-angle-right" aria-hidden="true"></i></a> </div>
      </li>
      
      
      
      
      
      <?php } ?>
     
    
<?php } ?>    
    
      
      
      
      
      

    </ul>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-sm-7 col-sm-push-5 left-block"> <span class="sm-head">Lorem ipsum dolor sit amet</span>
        <h2>WE ARE Intellify</h2>
        <p style="padding:0 0 10px 0 !important;">Intellify is the education initiative set up under Solve,a not for profit trust, established by the students and alumni of IIT Delhi with the aim to "solve" the problems plaguing the Indian Education System. </p>
        <ul>
          <li> We produce more Engineers than USA and China combined. </li>
          <li> Point of test is not to judge the strength or weaknesses but to certify him/her as Ok or Fail. </li>
          <li> Unless we fix our school kids are going to look boring, uninspiring and dull. </li>
          <li> Britain needed people who can sit behind desk work for long hours without asking questions. </li>
        </ul>
        <div class="know-more-wrapper"> <a href="#" class="know-more">Know More <span class="icon-more-icon"></span></a> </div>
      </div>
      <div class="col-sm-5 col-sm-pull-7">
        <div class="video-block">
          <div id="thumbnail_container"> <img  src="<?php echo base_url();?>images/about-video.jpg" id="thumbnail" class="img-responsive" alt=""> </div>
          
          <!-- <a href="#" class="start-video video"><img  src="<?php echo base_url();?>images/play-btn.png" alt=""></a> --> 
          
        </div>
      </div>
    </div>
  </div>
</section>

<!-- End About Section --> 

<!-- Start Cources Section -->

<section class="our-cources padding-lg">
  <div class="container">
    <h2> <span>Unique Features of our programs</span> What do you want to study?</h2>
    <ul class="course-list owl-carousel">
      <li>
        <div class="inner">
          <figure><img  src="<?php echo base_url();?>images/course-img1.jpg" alt=""></figure>
          <h3>Sed perspiciatis<span>omnis iste</span></h3>
          <p>A comprehensive study of modern business...</p>
          <div class="bottom-txt clearfix">
            <div class="duration">
              <h4>2 Year</h4>
              <span> Courses</span> </div>
            <a href="#"><span class="icon-more-icon"></span></a> </div>
        </div>
      </li>
      <li>
        <div class="inner">
          <figure><img  src="<?php echo base_url();?>images/course-img2.jpg" alt=""></figure>
          <h3>Sed perspiciatis<span>omnis iste</span></h3>
          <p>A comprehensive study of modern business...</p>
          <div class="bottom-txt clearfix">
            <div class="duration">
              <h4>1 Year</h4>
              <span> Courses</span> </div>
            <a href="#"><span class="icon-more-icon"></span></a> </div>
        </div>
      </li>
      <li>
        <div class="inner">
          <figure><img  src="<?php echo base_url();?>images/course-img3.jpg" alt=""></figure>
          <h3>Sed perspiciatis<span>omnis iste</span></h3>
          <p>A comprehensive study of modern business...</p>
          <div class="bottom-txt clearfix">
            <div class="duration">
              <h4>3 Year</h4>
              <span> Courses</span> </div>
            <a href="#"><span class="icon-more-icon"></span></a> </div>
        </div>
      </li>
      <li>
        <div class="inner">
          <figure><img  src="<?php echo base_url();?>images/course-img4.jpg" alt=""></figure>
          <h3>Sed perspiciatis<span>omnis iste</span></h3>
          <p>A comprehensive study of modern business...</p>
          <div class="bottom-txt clearfix">
            <div class="duration">
              <h4>2 Year</h4>
              <span> Courses</span> </div>
            <a href="#"><span class="icon-more-icon"></span></a> </div>
        </div>
      </li>
    </ul>
  </div>
</section>

<!-- End Cources Section --> 

<!-- Start Our Importance Section -->

<section class="our-impotance padding-lg">
  <div class="container">
    <ul class="row">
      <li class="col-sm-4 equal-hight">
        <div class="inner"> <img  src="<?php echo base_url();?>images/study-time-ico.jpg" alt="Malleable Study Time">
          <h3>Suicide rate in India</h3>
          <p>Every hour, one student commits suicide in India. The kind of education which is getting imparted in our education system is making them dull, boring and uninspired </p>
        </div>
      </li>
      <li class="col-sm-4 equal-hight">
        <div class="inner"> <img  src="<?php echo base_url();?>images/placement-ico.jpg" alt="Placement Assistance">
          <h3>One exam for all</h3>
          <p>Everybody is judged though the same set of parameters in the same test. As Einstein said, "Everyone is a genius. But if you judge a fish by its ability to climb a tree, it will live its whole life believing that it is stupid." </p>
        </div>
      </li>
      <li class="col-sm-4 equal-hight">
        <div class="inner"> <img  src="<?php echo base_url();?>images/easy-access-ico.jpg" alt="Easy To Access">
          <h3>Status of teachers in India</h3>
          <p>Mostly teachers in India are frustrated because of less respect for the profession and poor salary packages. Without appreciation of the subject, they struggle to impart the same in students. </p>
        </div>
      </li>
      <li class="col-sm-4 equal-hight">
        <div class="inner"> <img  src="<?php echo base_url();?>images/study-go-ico.jpg" alt="Study on the Go">
          <h3>Discipline necessarily means punishment.</h3>
          <p>Love has always been seen as one of the important gradients of learning process. Most of the times this is missing in our schools. </p>
        </div>
      </li>
      <li class="col-sm-4 equal-hight">
        <div class="inner"> <img  src="<?php echo base_url();?>images/get-innovative-ico.jpg" alt="Get an Innovative, In-depth Transition">
          <h3>Leave them with a sense of importance</h3>
          <p>Schools should be made self-sustaining centres of learning which should make the students feel they are succeeding in the sphere of life where their interest may lie with. It should be a continuous learning process not limited to school. School should help in finding your passion. The life skills are something we need to learn. It is very important to apply the concepts what we learn in real life. </p>
        </div>
      </li>
      <li class="col-sm-4 equal-hight">
        <div class="inner"> <img  src="<?php echo base_url();?>images/get-innovative-ico.jpg" alt="Get an Innovative, In-depth Transition">
          <h3>Changing paradigms:</h3>
          <p>Can we have an exam to span all of it? Maybe no. But we shall reach nearest we can. Check out how ISCO works here </p>
        </div>
      </li>
      <li class="col-sm-4 equal-hight">
        <div class="inner"> <img  src="<?php echo base_url();?>images/practical-ico.jpg" alt="Practical & Interactive Participation">
          <h3>What makes FINLAND different? <span>Google finds it out</span></h3>
          <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae.</p>
        </div>
      </li>
      <li class="col-sm-4 equal-hight">
        <div class="inner"> <img  src="<?php echo base_url();?>images/practical-ico.jpg" alt="Practical & Interactive Participation">
          <h3>Look in their eyes. </h3>
          <p>Students love when a teacher tries hard to remember their name. When he/she call their names just to ask their whereabouts. </p>
        </div>
      </li>
    </ul>
  </div>
</section>

<!-- End Our Importance Section --> 

<!-- Start How Study Section -->

<section class="how-study padding-lg">
  <div class="container">
    <h2> <span>Lorem ipsum dolor sit amet, consectetur </span> How do you want to study?</h2>
    <ul class="row">
      <li class="col-sm-4">
        <div class="overly">
          <div class="cnt-block">
            <h3>Lorem ipsum dolor sit amet</h3>
            <p>Lorem Ipsum is simply dummy text of the printing...</p>
          </div>
          <a href="#" class="more"><i class="fa fa-caret-right" aria-hidden="true"></i></a> </div>
        <figure><img  src="<?php echo base_url();?>images/how-study-img1.jpg" class="img-responsive" alt=""></figure>
      </li>
      <li class="col-sm-4">
        <div class="overly">
          <div class="cnt-block">
            <h3>Lorem ipsum dolor sit amet</h3>
            <p>Lorem Ipsum is simply dummy text of the printing...</p>
          </div>
          <a href="#" class="more"><i class="fa fa-caret-right" aria-hidden="true"></i></a> </div>
        <figure><img  src="<?php echo base_url();?>images/how-study-img2.jpg" class="img-responsive" alt=""></figure>
      </li>
      <li class="col-sm-4">
        <div class="overly">
          <div class="cnt-block">
            <h3> Lorem ipsum dolor sit amet </h3>
            <p>Lorem Ipsum is simply dummy text of the printing...</p>
          </div>
          <a href="#" class="more"><i class="fa fa-caret-right" aria-hidden="true"></i></a> </div>
        <figure><img  src="<?php echo base_url();?>images/how-study-img3.jpg" class="img-responsive" alt=""></figure>
      </li>
    </ul>
  </div>
</section>

<!-- End How Study Section --> 

<!-- Start Why Choose Section -->

<section class="why-choose padding-lg">
  <div class="container">
    <h2><span>The Numbers Say it All</span>Why Choose Us</h2>
    <ul class="our-strength">
      <li>
        <div class="icon"><span class="icon-certification-icon"> </span></div>
        <span class="">6+</span>
        <div class="title">PROJECTS</div>
      </li>
      <li>
        <div class="icon"><span class="icon-certification-icon"> </span></div>
        <span class="">100+</span>
        <div class="title">CITIES</div>
      </li>
      <li>
        <div class="icon"><span class="icon-book-icon"></span></div>
        <div class="couter-outer"><span class="">1500+</span></div>
        <div class="title">SCHOOLS</div>
      </li>
      <li>
        <div class="icon"><span class="icon-parents-icon"></span></div>
        <div class="couter-outer"><span class="">3000+</span></div>
        <div class="title">TEACHERS</div>
      </li>
      <li>
        <div class="icon"><span class="icon-student-icon"></span></div>
        <span class="">15000+</span>
        <div class="title">STUDENTS </div>
      </li>
    </ul>
  </div>
</section>

<!-- End Why Choose Section --> 

<!-- Start New & Events Section -->

<section class="news-events padding-lg">
  <div class="container">
    <h2><span>There are many ways to learn</span>News and events</h2>
    <ul class="row cs-style-3">
      <li class="col-sm-4">
        <div class="inner">
          <figure> <img  src="<?php echo base_url();?>images/new-event-img1.jpg" class="img-responsive">
            <figcaption>
              <div class="cnt-block"> <a href="#" class="plus-icon">+</a>
                <h3>We have added new features to Dream Palace</h3>
                <div class="bottom-block clearfix">
                  <div class="date">
                    <div class="icon"><span class="icon-calander-icon"></span></div>
                    <span>14 Feb</span> 2017</div>
                  <div class="comment">
                    <div class="icon"><span class="icon-chat-icon"></span></div>
                    <span>24</span> comments</div>
                </div>
              </div>
            </figcaption>
          </figure>
        </div>
      </li>
      <li class="col-sm-4">
        <div class="inner">
          <figure> <img  src="<?php echo base_url();?>images/new-event-img2.jpg" class="img-responsive">
            <figcaption>
              <div class="cnt-block"> <a href="#" class="plus-icon">+</a>
                <h3>We have added new features to Dream Palace</h3>
                <div class="bottom-block clearfix">
                  <div class="date">
                    <div class="icon"><span class="icon-calander-icon"></span></div>
                    <span>14 Feb</span> 2017</div>
                  <div class="comment">
                    <div class="icon"><span class="icon-chat-icon"></span></div>
                    <span>24</span> comments</div>
                </div>
              </div>
            </figcaption>
          </figure>
        </div>
      </li>
      <li class="col-sm-4">
        <div class="inner">
          <figure> <img  src="<?php echo base_url();?>images/new-event-img3.jpg" class="img-responsive">
            <figcaption>
              <div class="cnt-block"> <a href="#" class="plus-icon">+</a>
                <h3>We have added new features to Dream Palace</h3>
                <div class="bottom-block clearfix">
                  <div class="date">
                    <div class="icon"><span class="icon-calander-icon"></span></div>
                    <span>14 Feb</span> 2017</div>
                  <div class="comment">
                    <div class="icon"><span class="icon-chat-icon"></span></div>
                    <span>24</span> comments</div>
                </div>
              </div>
            </figcaption>
          </figure>
        </div>
      </li>
    </ul>
    <div class="know-more-wrapper"> <a href="#" class="know-more">More Post <span class="icon-more-icon"></span></a> </div>
  </div>
</section>

<!-- End New & Events Section --> 

<!-- Start Campus Tour Section -->

<section class="campus-tour padding-lg">
  <div class="container">
    <h2><span>OLorem ipsum dolor sit amet, consectetur</span>OUR GALLERY</h2>
  </div>
  <ul class="gallery clearfix">
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg1.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour1.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg2.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour2.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg3.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour3.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg4.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour4.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg5.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour5.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg6.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour6.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg7.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour7.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg8.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour8.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg9.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour9.jpg" class="img-responsive" alt=""></figure>
    </li>
    <li>
      <div class="overlay">
        <h3>Lorem ipsum</h3>
        <p>Lorem ipsum</p>
        <a class="galleryItem" href="images/tour-lg10.jpg"><span class="icon-enlarge-icon"></span></a> <a href="#" class="more"><span class="icon-gallery-more-arrow"></span></a> </div>
      <figure><img  src="<?php echo base_url();?>images/tour10.jpg" class="img-responsive" alt=""></figure>
    </li>
  </ul>
</section>

<!-- End Campus Tour Section --> 

<!-- Start logos Section -->

<!--<section class="logos">
  <div class="container">
    <ul class="owl-carousel clearfix">
      <li><a href="#"><img  src="<?php echo base_url();?>images/logo1.jpg" class="img-responsive" alt=""></a></li>
      <li><a href="#"><img  src="<?php echo base_url();?>images/logo2.jpg" class="img-responsive" alt=""></a></li>
      <li><a href="#"><img  src="<?php echo base_url();?>images/logo3.jpg" class="img-responsive" alt=""></a></li>
      <li><a href="#"><img  src="<?php echo base_url();?>images/logo4.jpg" class="img-responsive" alt=""></a></li>
      <li><a href="#"><img  src="<?php echo base_url();?>images/logo5.jpg" class="img-responsive" alt=""></a></li>
      <li><a href="#"><img  src="<?php echo base_url();?>images/logo6.jpg" class="img-responsive" alt=""></a></li>
    </ul>
  </div>
</section>-->

<!-- End logos Section --> 

<!-- Start Testimonial -->

<?php if($testimonials) {?><br />
<br />

<section class="testimonial padding-lg">
  <div class="container">
    <div class="wrapper">
      <h2>Client Testimonials</h2>
      <ul class="testimonial-slide">
        <?php 
  foreach($testimonials as $testimonial) { ?><?php if($testimonial['home']=='1'){?>
        <li> <?php echo $testimonial['description']; ?> <span><?php echo $testimonial['name']; ?>, <span><?php echo $testimonial['designation']; ?></span></span> </li>
        <?php } ?> <?php } ?>
      </ul>
      
      <!--<div id="bx-pager"> <a data-slide-index="0" href="#"><img  src="<?php echo base_url();?>images/testimonial-thumb1.jpg" class="img-circle" alt=""/></a> <a data-slide-index="1" href="#"><img  src="<?php echo base_url();?>images/testimonial-thumb2.jpg" class="img-circle" alt="" /></a> <a data-slide-index="2" href="#"><img  src="<?php echo base_url();?>images/testimonial-thumb3.jpg" class="img-circle" alt="" /></a> <a data-slide-index="3" href="#"><img  src="<?php echo base_url();?>images/testimonial-thumb3.jpg" class="img-circle" alt="" /></a></div>--> 
    </div>
  </div>
</section>
<br />
<br />
<?php } ?>

<!-- End Testimonial --> 

<!-----







<div class="demo-parallax parallax section looking-photo" data-stellar-background-ratio="0.7" style="background-image:url('<?php echo base_url('images/demo_04.jpg'); ?>');">

            <div class="container">

                <div class="row centermessage text-left">

                    <div class="col-md-7">

                        <div class="tagline"><h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit</h4></div>

                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo Nemo enim ipsam voluptatem.</p> 

                    </div>



                    <div class="col-md-5">

                        <form id="homeregistrationform" name="homeregistrationform" method="post" action="<?php echo $action; ?>">

                            <div class="row section-signup semitrans">

                                <div class="col-md-12">

                                    <div class="form-group has-icon-left form-control-name">

                                        <label class="sr-only" for="inputName">First name</label>

                                        <input type="text" class="form-control form-control-lg" id="firstname" name="firstname" placeholder="First name">

                                    </div>

                                </div>

                                <div class="col-md-12">

                                    <div class="form-group has-icon-left form-control-name">

                                        <label class="sr-only" for="inputName">Last name</label>

                                        <input type="text" class="form-control form-control-lg" id="lastname" name="lastname" placeholder="Last name">

                                    </div>

                                </div>

                                <div class="col-md-12">

                                    <div class="form-group has-icon-left form-control-email">

                                        <label class="sr-only" for="inputEmail">Email address</label>

                                        <input type="email" class="form-control form-control-lg" id="email" name="email" placeholder="Email address" autocomplete="off">

                                    </div>

                                </div>

                                <div class="col-md-12">

                                    <div class="form-group">

                                        <button type="submit" class="btn btn-primary btn-block">Sign up for free!</button>

                                    </div>

                                </div>

                                <div class="col-md-12">

                                    <p>Your email is safe with us and we hate spam as much as you do.</p>

                                </div>

                            </div>

                        </form>

                    </div>

                </div>

            </div>



        ---->
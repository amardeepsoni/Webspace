
<div id="page-content-wrapper">
    <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
    <div class="demo-parallax parallax section looking-photo nopadbot" data-stellar-background-ratio="0.5" style="background-image:url('<?php echo base_url();?>schoolassest/upload/demo_02.jpg');">
        <div class="page-title section nobg">
            <div class="container-fluid">





                <div class="clearfix">
                    <div class="title-area pull-left">
                        <h2> <?php echo $heading; ?> </h2>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section">
        <div class="container-fluid">
            <?php print_r($queries) ?>
        </div>
    </div>


<link href="<?php echo base_url();?>schoolassest/css/schoolacount.css" rel="stylesheet">

<div id="page-content-wrapper"> <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
  <div class="demo-parallax parallax section looking-photo nopadbot" data-stellar-background-ratio="0.5" style="background-image:url('<?php echo base_url();?>schoolassest/upload/Intellify_collage.jpg'); background-attachment: inherit ; background-repeat: no-repeat; background-position: "0px 0px";">
    <div class="page-title section nobg">
      <div class="container-fluid">
        <div class="clearfix">
          <div class="title-area pull-left">
            <!-- <h2>School account</h2> -->
            <h2><strong>Welcome  </strong><?php echo $schoolinfo->name; ?>. </h2>
          </div>
          <!-- /.pull-right -->
          <div class="pull-right hidden-xs">
            <div class="bread">
              <ol class="breadcrumb">
                <li><a href="<?php echo base_url();?>schoolaccount">Home</a></li>
                <li class="active">School account</li>
              </ol>
            </div>
            <!-- end bread --> 
          </div>
          <!-- /.pull-right --> 
        </div>
        <!-- end clearfix --> 
      </div>
    </div>
    <!-- end page-title --> 
  </div>
  <div class="section">
    <div class="container-fluid">
      <!-- Notify user for any Error -->
      <?php if ($this->session->flashdata('schoolloginnotify')) { ?>
      <div class="alert alert-danger">
        <?= $this->session->flashdata('schoolloginnotify') ?>
      </div>
      <?php } ?>
      <!-- Details of the schools from the schoolinfo varaible -->
      <!-- <h3><strong>Welcome  </strong><?php echo $schoolinfo->name; ?>. </h3> -->
      <div class="cnt-block">
        <div class="row">
          <div class="col-lg-7 table">
            <table>
              <tr>
                <td>Contact Person</td>
                <td><?php echo $schoolinfo->contact_person_name; ?></td>
              </tr>
              <tr>
                <td>Email</td>
                <td><?php echo $schoolinfo->email; ?></td>
              </tr>
              <tr>
                <td>Mobile</td>
                <td><?php echo $schoolinfo->mobile; ?></td>
              </tr>
              <tr>
                <td>Alternate Mobile</td>
                <td><?php echo $schoolinfo->mobile1; ?></td>
              </tr>
              <tr>
                <td>Designation</td>
                <td> <?php echo $schoolinfo->contact_person_designation; ?></td>
              </tr>
              <?php if($schoolinfo->intern){?>
              <tr>
                <td>Intern</td>
                <td></td>
              </tr>
              <?php }?>
              <tr>
                <td>Address</td>
                <td> <?php echo $schoolinfo->address; ?></td>
              </tr>
            </table>
        </div>
        <div class="col-lg-4 botton">
          
           <!-- <a href="<?php echo base_url();?>editschoolprofile"> <button  class="btn btn-secondary">Edit Profile</button> </a>
           <a href="<?php echo base_url();?>editschoolpassword"><button  class="btn btn-secondary">Edit Password</button> </a> -->
           <a href="<?php echo base_url();?>editschoolprofile" class="btn btn-secondary"  >Edit Profile</a>
           <a href="<?php echo base_url();?>editschoolpassword"  class="btn btn-secondary">Edit Password </a>
              </div>
      </div>
      <div class="row"></div>
    </div>
    <br />

    
  </div>
</div>
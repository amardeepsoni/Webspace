<link href="<?php echo base_url();?>schoolassest/css/studentlist.css" rel="stylesheet">

<div id="page-content-wrapper">
<a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
<div class="demo-parallax parallax section looking-photo nopadbot" data-stellar-background-ratio="0.5" style="background-image:url('<?php echo base_url();?>schoolassest/upload/demo_02.jpg');">
  <div class="page-title section nobg">
    <div class="container-fluid">
      <div class="clearfix">
        <div class="title-area pull-left">
          <h2><?php echo $heading; ?> <small></small></h2>
        </div>
        <!-- /.pull-right -->
        <div class="pull-right hidden-xs">
          <div class="bread">
            <ol class="breadcrumb">
              <?php 

              if(isset($breadcrumbs)) {

                $bi=0;

                foreach($breadcrumbs as $rw) {

                  if($bi>0) {

                    echo "";

                  }

                  echo "<li><a href='".$rw['href']."'>".$rw['text']."</a></li>";

                $bi++;}

              }

            ?>
            </ol>
          </div>
          <!-- end bread --> 
        </div>
        <!-- /.pull-right --> 
      </div>
      <!-- end clearfix --> 
    </div>
  </div>
  <!-- end page-title --> 
</div>
<div class="section">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="widget-title countsert">
          <h3>Student
            <?php   if($allstudents) { 
              $abhy=1;  
              foreach ($allstudents as $value) {
                if($value['category_id']==$schoolinfo->category_id){?>
                    <span>(<?php echo $abhy;?>)</span>
                    <?php 
                    $abhy++;
                }
              }
            }
            ?>
          </h3>
          <hr>
        </div>
      <div class="datatablecon">
        <div>
          <a class="btn btn-danger" href="<?php echo base_url('studentlist/deleteall/'.$category_id);?>" class="del_btn">DeleteAll</a>
          <a class="btn btn-info" href="<?php echo base_url('studentlist/export_csv');?>">Export Student Details...</a><br><br>
        </div>
        <!-- <div id="datatable-checkbox_filter" class="dataTables_filter"><label>Search:<input type="search" class="" placeholder="" aria-controls="datatable-checkbox"></label></div> -->
        <table id="datatable-checkbox" class="dataTable">
          <thead>
            <!-- <tr style="display:none">
              <th ></th>
              <th ></th>
            </tr> -->
            <tr>
              <th>Student Name</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>R No</th>
              <th>Class</th>
              <th>Status</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody> 
          <?php $row = 1;?>   
            <?php if($allstudents) {?>
            <?php foreach ($allstudents as $value) { ?>
            <?php if($value['category_id']==$schoolinfo->category_id){?>
            <tr>
              <th style="display:none">1</th>
              <td> <?php echo $value['firstname']; ?></td>
              <td> <?php echo $value['email']; ?></td>
              <td><?php echo $value['mobile']; ?></td>
              <td><?php if ($value['status'] == -1) echo "-"; else echo $value['registrationno']; ?></td>
              <td><?php echo $value['class']; ?></td>
              <td> <?php if ($value['status'] == -1) echo "Waiting for approval"; else echo "Approved"?></td>
              <td> <button type="button" class="btn btn-info" data-toggle="modal" data-target="<?php echo "#myModal". $row ;?>">Edit</button></td>
              <td> <a class="btn btn-danger" href="<?php echo base_url("studentlist/delete_row/".$value['registrationno']);?>" class="del_btn">Delete</a></td>
              


                <!-- <div class="friendbox clearfix">
                  <div class="row">
                    <div class="col-md-4">
                      <div class="team-desc">
                        <h3><a href="#"><?php echo $value['firstname']; ?> <?php echo $value['lastname']; ?><?php echo $value['category_id']; ?></a></h3>
                        <small>Student</small>
                      </div> -->
                    <!-- end team-desc --> 
                    <!-- </div>
                    <div class="col-md-8">
                      <p><strong>Mobile:</strong> <?php echo $value['mobile']; ?>, <strong>Email:</strong><?php echo $value['email']; ?></p>
                      <p><strong>R No.</strong> <?php echo $value['registrationno']; ?></p>
                      <p><strong>Level.</strong> <?php echo $value['level']; ?></p>
                      <p><strong>Class.</strong> <?php echo $value['class']; ?></p>
                      <p><strong>Status.</strong> <?php if ($value['status'] == -1) echo "Waiting for approval"; else echo "Approved"?></p> -->
                      <!-- Button to Open the Modal -->
                      <!-- <button type="button" class="btn btn-info" data-toggle="modal" data-target="<?php echo "#myModal". $row ;?>">Edit</button> -->
                        <!-- The Modal -->
                        <div class="modal" id="<?php echo "myModal". $row ;?>">
                          <div class="modal-dialog">
                            <div class="modal-content">

                              <!-- Modal Header -->
                              <div class="modal-header">
                                <h4 class="modal-title">Edit details.</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>

                              <!-- Modal body -->
                              <div class="modal-body">
                                <form name="Updateform" class="defaultform row "  method="post" action="<?php echo base_url("studentlist/update/".$value['registrationno']);?>" id="updateform">
                            
                                        <div class="form-group col-lg-6">
                                          <label>First Name</label>
                                          <input name="firstname"value="<?php echo $value['firstname'];?>" type="text" id="firstname" class="form-control">
                                        </div>
                                        <div class="form-group col-lg-6">
                                          <label>Last Name</label>
                                          <input name="lastname" value="<?php echo $value['lastname']; ?>" type="text" id="lastname" class="form-control">
                                        </div>
                                        <div class="form-group col-lg-6">
                                          <label>Email</label>
                                          <input name="email" value="<?php echo $value['email'];?>" type="text" id="email" class="form-control">
                                        </div>
                                        <div class="form-group col-lg-6">
                                          <label>Mobile</label>
                                          <input name="mobile" value="<?php echo $value['mobile'];?>" type="text" id="mobile" class="form-control">
                                        </div>
<!--                                        <div class="form-group col-lg-12">-->
<!--                                          <label>Select level</label>-->
<!--                                          <select class="form-control" id="level" name="level">-->
<!--                                            --><?php //if($allschoollavels){
//                                              foreach($allschoollavels as $allschoollavel){?>
<!--                                                <option value="--><?php //echo $allschoollavel['id']; ?><!--">--><?php //echo $allschoollavel['name']; ?><!--</option>-->
<!--                                              --><?php //} } ?>
<!--                                          </select> -->
<!---->
<!--                                        </div> -->
                                        <div class="form-group col-lg-12">
                                          <label>Select Class</label>
                                          <select class="form-control" id="class" name="class">
                                            <?php if($allschoolclasss){
                                              foreach($allschoolclasss as $allschoolclass){?>
                                                  <?php if($allschoolclass['name'] == $value['class'])
                                                            echo '<option selected value="'.$allschoolclass["name"].'">'.$allschoolclass["name"].'</option>';
                                                        else
                                                            echo '<option value="'.$allschoolclass["name"].'">'.$allschoolclass["name"].'</option>';
                                                        ?>
                                              <?php } } ?>
                                          </select>
                                        </div>
                                        <div style="align=center">
                                                <button type="submit" name="update" id="update" class="btn btn-info">Update</button>
                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        </div>
                                </form>
                                </div>
                            <!-- </div>
                          </div>
                        </div>
                        <?php $row++;  ?>
                        <a class="btn btn-danger" href="<?php echo base_url("studentlist/delete_row/".$value['registrationno']);?>" class="del_btn">Delete</a>
                      </div>  -->
                      <!-- end col --> 
                    <!-- </div> -->
                    <!-- end row --> 
                  <!-- </div>
                </div> -->
              <!-- </td> -->
            </tr>
            <?php }  ?>
            <?php }  ?>
            <?php }   ?>
          </tbody>
        </table>
        </div>
      </div>
    </div>
  </div>
</div>

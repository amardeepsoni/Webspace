<footer class="copyrights">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6 col-sm-12">
        <div class="copylinks">
          <p>Copyrights &copy; 2016 Intellify. All Rights Reserved.</p>
        </div>
      </div>
      <div class="col-md-6 col-sm-12">
        <div class="footer-social text-right"> <a class="dmtop" href="#"><i class="fa fa-angle-up"></i></a> </div>
      </div>
    </div>
  </div>
</footer>
</div>
</div>
<script src="<?php echo base_url();?>schoolassest/js/all.js"></script> 
<script src="<?php echo base_url();?>schoolassest/js/custom.js"></script>
<script src="https://www.waytopinnacle.com/js/datatable/bootstrap.js"></script> 
<script src="https://www.waytopinnacle.com/js/datatable/jquery_005.js"></script> 
<script src="https://www.waytopinnacle.com/js/datatable/datatable.js"></script> 

</body>
</html>
<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Round 2 | Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/examPortal/dist/styles.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
</head>

<body id="exam-dashboard">
<nav class="navbar navbar-light navigation-clean">
    <p class="navbar-brand"><?php echo 'Registration Number '.$username?></p>
</nav>
<div class="skill-boxed">
    <div class="cnt">
        <div class="logo-cont"><img src="https://codepipeline-ap-south-1-323045938757.s3.ap-south-1.amazonaws.com/Intellify_IMG/logo.png" class="intellify-logo"/></div>
        <div class="intro">
            <h2 class="text-center">International Science &amp; Creativity Olympiad</h2>
            <p class="text-center">Welcome to the student portal of International Science and Creativity Olympiad. This portal will allow you to assess and enhance your skills.
            </p>
        </div>
        <div class="row myrow">
            <div class="col-md-6 col-lg-2 item">
                <div class="box">
                    <a style="  color:black;
" href="<?php echo base_url().round2path.'/Instructions/Quiz1' ?>">
                    <img class="rounded-circle" src="https://codepipeline-ap-south-1-323045938757.s3.ap-south-1.amazonaws.com/Intellify_IMG/analytics.jpg" />
                    <h3 class="name">Analytical Reasoning
                    </h3>
                    <p class="description"> </p>
                    <div class="social"></div>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-2 item">
                <div class="box"><a style="  color:black;
" href="<?php echo base_url().round2path.'/Instructions/Quiz2' ?>"><img class="rounded-circle" src="https://codepipeline-ap-south-1-323045938757.s3.ap-south-1.amazonaws.com/Intellify_IMG/verbal.jpg" />
                    <h3 class="name">Quantitative Aptitude
                        </h3>
                    <p class="description"></p>
                    <div class="social"></div>
                </div>
            </div>
            <div class="col-md-6 col-lg-2 item">
                <div class="box"><a style="  color:black;
" href="<?php echo base_url().round2path.'/Instructions/Quiz3' ?>"><img class="rounded-circle" src="https://codepipeline-ap-south-1-323045938757.s3.ap-south-1.amazonaws.com/Intellify_IMG/reading.png" />
                    <h3 class="name">Memory Speed Index
                        </h3>
                    <p class="description"> </p>
                    <div class="social"></div>
                </div>
            </div>
            <div class="col-md-6 col-lg-2 item">
                <div class="box"><a style="  color:black;
" href="<?php echo base_url().round2path.'/Instructions/Quiz4' ?>"><img class="rounded-circle" src="https://codepipeline-ap-south-1-323045938757.s3.ap-south-1.amazonaws.com/Intellify_IMG/cognitive.jpg" />
                    <h3 class="name">Visual and Spatial Skills
                        </h3>
                    <p class="description"> </p>
                    <div class="social"></div>
                </div>
            </div>
            <div class="col-md-6 col-lg-2 item">
                <div class="box"><a style="  color:black;
" href="<?php echo base_url().round2path.'/Instructions/Quiz5' ?>"><img class="rounded-circle" src="https://codepipeline-ap-south-1-323045938757.s3.ap-south-1.amazonaws.com/Intellify_IMG/logical.jpg" />
                        <h3 class="name">Verbal Comprehension
                        </h3>
                        <p class="description"> </p>
                        <div class="social"></div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>

</html>

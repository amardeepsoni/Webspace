<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/examPortal/dist/styles.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
</head>

<body>
<div>
    <div class="header-blue">
        <div class="navbar navbar-expand-md">
            <div class="collapse navbar-collapse" id="navcol-1">
                <div style="min-width:85%;">
                    <p style="padding-right:20px" class="navbar-brand" >Name: <?php echo $_SESSION['round2_login']['firstname'].' ' .$_SESSION['round2_login']['lastname'] ?></p>
                    <p style="padding-right:20px" class="navbar-brand" >Registration ID: <?php echo $_SESSION['round2_login']['username'] ?></p>
                    <p style="padding-right:20px" class="navbar-brand" >Skill Name: <?php
                        if($quizDetails->skill_id == 1)
                            echo 'Analytical Reasoning';
                        else if($quizDetails->skill_id == 2)
                            echo 'Quantitative Aptitude';
                        else if($quizDetails->skill_id == 3)
                            echo 'Memory Speed Index';
                        else if($quizDetails->skill_id == 4)
                            echo 'Visual and Spatial Skills';
                        else if($quizDetails->skill_id ==5)
                            echo 'Verbal Comprehension';
                        ?></p>
                    <div style="font-size:25px;">
                        Timer: <p style="display:inline" id="demo"></p>
                    </div>
                </div>
                <button class="btn btn-light button1 submitQuiz">SUBMIT EXAM</button>
            </div>
        </div>
    </div>
</div>
<div class="card-group">
    <div class="card-question">
        <div id="ques" class="card-body">
<!--            <h4 class="card-title">Question 9</h4>-->
<!--            <p class="card-text" style="padding-top:5%;">The table below has question-wise data on the performance of students in an examination. The marks for each question are also listed. There is no negative or partial marking in the examination. What is the average of the marks obtained by the class in the examination</p>-->
<!---->
<!--            <img id="myImg" src="assets/img/question_image.png" alt="question">-->
<!---->
<!--            <div id="myModal" class="modal">-->
<!--                <span class="close">&times;</span>-->
<!--                <img class="modal-content" id="img01">-->
<!--                <div id="caption"></div>-->
<!--            </div>-->
        </div>
    </div>
    <div class="card">
        <div id="options" class="card-body card-body-options">
<!--            <h4 class="card-title">Options</h4>-->
<!--            <form class="card-body">-->
<!--                <input type="checkbox" id="op1" name="op-1" value="A">-->
<!--                <label for="op1">1.34</label>-->
<!--                <input type="checkbox" id="op2" name="op-1" value="B">-->
<!--                <label for="op2">1.74</label>-->
<!--                <input type="checkbox" id="op3" name="op-1" value="C">-->
<!--                <label for="op3">3.02</label>-->
<!--                <input type="checkbox" id="op4" name="op-1" value="D">-->
<!--                <label for="op4">3.91</label>-->
<!--            </form>-->
        </div>
    </div>
    <div class="card">
        <div class="card-body card-body-panel">
            <h4 class="card-title">Question Panel</h4>
            <div id="myPanel"></div>
        </div>
    </div>
</div>

<div style="text-align:center; padding-top:3%" id="sendButton">
    <button class="btn btn-primary" id="saveAndNext" type="submit">Save & Next</button>
</div>

<script type="text/javascript">

    $(document).ready(function(){

        let shuffle = (a) => a.sort(() => Math.random() - 0.5);
        let quesData = shuffle(<?php echo json_encode($questionDetails) ?>);
        // console.log(quesData);
        let count = 0;
        let userResponse = [];
        let updateDOM = () => {
            $('#ques').html(
                '<h4 class="card-title">Question '+(count+1)+'</h4>' +
                '<p class="card-text" style="padding-top:5%;">'+quesData[count].qnstext+'</p>' +
                '<img id="myImg" src='+quesData[count].questions_img+'alt="question">'+
                '<div id="myModal" class="modal">'+
                '<span class="close">&times;</span>'+
                '<img class="modal-content" id="img01">'+
                '<div id="caption"></div>'+
                '</div>'
            );
            if(quesData[count].options.length === 4) {
                $('#options').html(
                    '<h4 class="card-title">Options</h4>'+
                    '<form class="card-body">'+
                    '<input type="checkbox" id="op1" name="ans" value="A">'+
                    '<label for="op1">'+quesData[count].options[0].text+'</label>'+
                    '<input type="checkbox" id="op2" name="ans" value="B">'+
                    '<label for="op2">'+quesData[count].options[1].text+'</label>'+
                    '<input type="checkbox" id="op3" name="ans" value="C">'+
                    '<label for="op3">'+quesData[count].options[2].text+'</label>'+
                    '<input type="checkbox" id="op4" name="ans" value="D">'+
                    '<label for="op4">'+quesData[count].options[3].text+'</label>'+
                    '</form>'
                );
            }
            else if(quesData[count].options.length === 2) {
                $('#options').html(
                    '<form class="card-body">'+
                    '<input type="checkbox" id="op1" name="ans" value="A">'+
                    '<label for="op1">'+quesData[count].options[0].text+'</label>'+
                    '<input type="checkbox" id="op2" name="ans" value="B">'+
                    '<label for="op2">'+quesData[count].options[1].text+'</label>'+
                    '</form>'
                );
            }
            else if(quesData[count].options.length === 0) {
                $('#options').html(
                    '<form class="card-body">'+
                    '<input type="number" id="op1" name="ans">'+
                    '</form>'
                );
            }
        };
        updateDOM();
        for(let i = 1; i<=quesData.length;i++)
        $('#myPanel').append('<div id="qpanel'+i+'" class="numberCircle">'+i+'</div>');
        let saveQues = () => {
            if(quesData[count].options.length) {
                userResponse[count] = {
                    'quesid': quesData[count].quesid,
                    'userAnswer': $("input[name='ans']:checked").val()
                };
            }
            else {
                userResponse[count] = {
                    'quesid': quesData[count].quesid,
                    'userAnswer': $("input[name='ans']").val()
                };
            }
            $.ajax({
                type: "POST",
                url: "<?php echo base_url().round2path.'/Quiz/handleUserResponse' ?>",
                data: userResponse[count],
                cors: true,
                xhrFields: {
                    withCredentials: true
                },
                async: true,
                crossDomain: true,
                dataType: 'json'
            });

            if(userResponse[count].userAnswer)
                $('#qpanel'+(count+1)).addClass('ques_attempted');
            count++;
            if(count === quesData.length-1)
                $('#sendButton').html('<button class="btn btn-primary submitQuiz" type="submit">Submit</button>');
            updateDOM();
            console.log(userResponse);
        };

        let submitQuizResponse = () => {
            for(let i = count ; i<quesData.length ; i++) {
                userResponse[i] = {
                    'quesid': quesData[i].quesid
                };
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url() . round2path . '/Quiz/handleUserResponse' ?>",
                    data: userResponse[i],
                    cors: true,
                    xhrFields: {
                        withCredentials: true
                    },
                    async: true,
                    crossDomain: true,
                    dataType: 'json'
                });
            }
            location.reload();
        };

        //console.log(count);
        $(document).on('click','#saveAndNext',saveQues);
        $(document).on('click','.submitQuiz', submitQuizResponse);

        $(document).on('click', 'input:checkbox' ,function() {
            // in the handler, 'this' refers to the box clicked on
            var $box = $(this);
            if ($box.is(":checked")) {
                // the name of the box is retrieved using the .attr() method
                // as it is assumed and expected to be immutable
                var group = "input:checkbox[name='" + $box.attr("name") + "']";
                // the checked state of the group/box on the other hand will change
                // and the current value is retrieved using .prop() method
                $(group).prop("checked", false);
                $box.prop("checked", true);
            } else {
                $box.prop("checked", false);
            }
        });

        var x = setInterval(function() {
            var countDownDate = new Date("July 30, 2019 18:59:59").getTime();
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Output the result in an element with id="demo"
            document.getElementById("demo").innerHTML = hours + "h "
                + minutes + "m " + seconds + "s ";

            // If the count down is over, write some text
            if (distance < 0) {
                clearInterval(x);
                submitQuizResponse();
            }
        }, 1000);

        var modal = document.getElementById("myModal");
        var img = document.getElementById("myImg");
        var modalImg = document.getElementById("img01");
        var captionText = document.getElementById("caption");
        img.onclick = function(){
            modal.style.display = "block";
            modalImg.src = this.src;
            captionText.innerHTML = this.alt;
        };
        var span = document.getElementsByClassName("close")[0];
        span.onclick = function() {
            modal.style.display = "none";
        };
    });
</script>
</body>

</html>

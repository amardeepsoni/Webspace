<!DOCTYPE html>
<html lang="en">
<head>
    <title>Intellify Registration Form</title>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?php echo base_url()?>/assets/registration/images/logo.png">
    <!--===============================================================================================-->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--===============================================================================================-->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/registration/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/registration/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/registration/vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/registration/vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/registration/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/registration/vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/registration/css/util.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/assets/registration/css/main.css">


    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script
            src="https://code.jquery.com/jquery-3.4.1.min.js"
            integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
            crossorigin="anonymous"></script>

    <!--===============================================================================================-->
</head>
<body style="background-color: #abdde57d">
<?php
if (isset($flag)) {
    if($flag) {
        echo '<script type="text/javascript"> swal({
            title: "Success",
            text: "Redirecting in 2 seconds",
            type:"Success",
            timer:2000,
            showConfirmButton: false,
            })
            .then( () =>  window.location.href ="'.base_url().'/schoollogin'.'");
        </script>';
    }
    else
        echo '<script type="text/javascript"> swal({ icon: "error" , text:"'.$message.'" }) </script>';
}
?>

<!---->
<!--	<div class="container-contact100">-->
<!--		<div class="wrap-contact100">-->
<!--            <div class="contact100-more flex-col-c-m" style="background-color: #abdde5;">-->
<!--            </div>-->
<div style="margin: 3em auto;">
    <form style="margin: auto; background-color: #ffffff; border-radius: 20px;" class="contact100-form validate-form" action="<?php echo $action?>" method="post" enctype="multipart/form-data" data-toggle="validator">
				<span class="contact100-form-title">
					Intellify Registration Form
				</span>

        <h3 style="color:green; font-size:15px;">Personal Details</h3><br />

        <div class="wrap-input100 validate-input" data-validate="Enter Your Full Name">
            <label class="label-input100" for="firstname">Your Name *</label>
            <input id="firstname" class="input100" type="text" name="contact_person_name" placeholder="Enter Your Full Name">
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100">
            <div class="label-input100">You are *</div>
            <div>
                <select class="js-select2" name="contact_person_designation">
                    <option value="principal" selected>Principal</option>
                    <option value="teacher">Teacher</option>
                </select>
                <div class="dropDownSelect2"></div>
            </div>
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
            <label class="label-input100" for="email">Email*</label>
            <input id="email" class="input100" type="email" name="email" placeholder="Enter your email address">
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate = "Enter your password">
            <label class="label-input100" for="cpassword1">Password *</label>
            <input id="cpassword1" class="input100" type="password" name="password1" placeholder="Enter your password">
            <span class="focus-input100"></span>
            <div style="padding-left: 1em; padding-top: 1em; "><input type="checkbox" onclick="myFunction3()"> Show Password<br/><br /></div>
        </div>

        <div class="wrap-input100 validate-input" data-validate = "Enter your password">
            <label class="label-input100" for="cpassword2">Repeat Password *</label>
            <input id="cpassword2" class="input100" type="password" name="password2" placeholder="Enter your password again">
            <span class="focus-input100"></span>
            <div style="padding-left: 1em; padding-top: 1em; "><input type="checkbox" onclick="myFunction4()"> Show Password<br/><br /></div>
        </div>


        <br /><h3 style="color:green; font-size:15px;">School's Details</h3><br />

        <div class="wrap-input100 validate-input" data-validate="The official full name of the school should be written">
            <label class="label-input100" for="schoolname">School Name *</label>
            <input id="schoolname" class="input100" type="text" name="name" placeholder="Enter Your School Name">
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate="Enter Phone Number">
            <label class="label-input100" for="phone1">School's Contact *</label>
            <input id="phone1" class="input100" type="number" name="mobile" placeholder="Enter Phone Number">
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate="Enter Alternate Phone Number">
            <label class="label-input100" for="phone2">School's Alternate Contact *</label>
            <input id="phone2" class="input100" type="number" name="mobile1" placeholder="Enter Alternate Phone Number">
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate = "School Address is required">
            <label class="label-input100" for="address">School Address *</label>
            <textarea id="address" class="input100" name="address" placeholder="Address"></textarea>
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100">
            <div class="label-input100">School Type *</div>
            <div>
                <select class="js-select2" name="school_type">
                    <option value="government" selected>Government</option>
                    <option value="private">Private</option>
                </select>
                <div class="dropDownSelect2"></div>
            </div>
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100">
            <label class="label-input100" for="internID">Intern's Referral ID (optional) </label>
            <input id="internID" class="input100" type="text" name="intern_id" placeholder="Enter Referral Code">
            <span class="focus-input100"></span>
        </div>

        <br /><h3 style="color:green; font-size:15px;">School's Olympiad Manager</h3><br />

        <div class="wrap-input100">
            <label class="label-input100" for="mName">Name </label>
            <input id="mName" class="input100" type="text" name="manager_name" placeholder="Enter Manager's Name">
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100">
            <label class="label-input100" for="mEmail">Email </label>
            <input id="mEmail" class="input100" type="email" name="manager_email" placeholder="Enter Manager's Email">
            <span class="focus-input100"></span>
        </div>

        <div class="wrap-input100">
            <label class="label-input100" for="mContact">Contact Number </label>
            <input id="mContact" class="input100" type="number" name="manager_contactno" placeholder="Contact Number">
            <span class="focus-input100"></span>
        </div>


        <div class="container-contact100-form-btn">
            <button id="submit" class="contact100-form-btn" >
                Submit
            </button>
        </div>
        <p class="copyright-w3ls" style="text-align: center;font-size: 1em;font-weight: normal;padding: 1em 0 2em 0;color: #000;letter-spacing: 1px;">© 2019 Intellify. All Rights Reserved <br>
            <img src="<?php echo base_url()?>/assets/registration/images/logo.png" height="30px" width="auto">
        </p>
    </form>
</div>
<!---->
<!--			<div class="contact100-more flex-col-c-m" style="background-color: #abdde5;">-->
<!--			</div>-->
<!--		</div>-->
<!--	</div>-->





<!--===============================================================================================-->
<!--===============================================================================================-->
<script src="<?php echo base_url()?>/assets/registration/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="<?php echo base_url()?>/assets/registration/vendor/bootstrap/js/popper.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><!--===============================================================================================-->
<script src="<?php echo base_url()?>/assets/registration/vendor/select2/select2.min.js"></script>
<script>
    function passCheck() {
        var x = document.getElementById("cpassword1").value;
        var y = document.getElementById("cpassword2").value;
        //console.log(x,y);
        if( x === y){
            console.log('same');
            document.getElementById("submit").disabled = false;
            document.getElementById("cpassword2").style.color = 'black';
        }
        else{
            //console.log("avasv");
            document.getElementById("submit").disabled = true;
            document.getElementById("cpassword2").style.color = 'red';
        }

    }
    $("#cpassword1, #cpassword2")
        .on("keydown", function(e){
            if(e.keyCode == 13 && e.keyCode == 9){
                passCheck();
            }
        })
        .on("blur",function(){
            passCheck();
        })
        .on("focus",function(){
            passCheck();
        });
    function myFunction3() {
        var x = document.getElementById("cpassword1");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    function myFunction4() {
        var x = document.getElementById("cpassword2");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    $(".js-select2").each(function(){
        $(this).select2({
            minimumResultsForSearch: 20,
            dropdownParent: $(this).next('.dropDownSelect2')
        });
    })
    $(".js-select2").each(function(){
        $(this).on('select2:open', function (e){
            $(this).parent().next().addClass('eff-focus-selection');
        });
    });
    $(".js-select2").each(function(){
        $(this).on('select2:close', function (e){
            $(this).parent().next().removeClass('eff-focus-selection');
        });
    });

</script>
<!--===============================================================================================-->
<script src="<?php echo base_url()?>/assets/registration/vendor/daterangepicker/moment.min.js"></script>
<script src="<?php echo base_url()?>/assets/registration/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="<?php echo base_url()?>/assets/registration/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="<?php echo base_url()?>/assets/registration/js/main.js"></script>

</body>
</html>

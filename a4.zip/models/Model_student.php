<?php

class Model_student extends CI_Model {

    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    public function getstudents() {

		$this->db->select('*');

		$this->db->from('student');

        $this->db->order_by("level asc, class asc, username asc");
        $query = $this->db->get();

        return $query->result();

	}
	public function user_delete($id){

		$this->db->where('registrationno', $id);
		$this->db->delete('student');
  }
  public function deleteall($id){

	$this->db->where('category_id', $id);
	$this->db->delete('student');
}

}

?>
<?php
class Model_studymaterial extends CI_Model {
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function add($data)
	{
		$this->db->insert('amspeimage', $data);
	}
public function edit($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('amspeimage',$data);
	}
public function delete($data)
	{
		for ($i = 0; $i <= count($data); $i++)
        {
        $this->db->where('id', $data[$i]);
        $this->db->delete('amspeimage');
        }
	}

public function active($data)
	{
		for ($i = 0; $i <= count($data); $i++)
        {
        	$postdata=array(
			 'status'=>1,
			 );
	        $this->db->where('id', $data[$i]);
	        $this->db->update('amspeimage',$postdata);
        }
	}
public function inactive($data)
	{
		for ($i = 0; $i <= count($data); $i++)
        {
        	$postdata=array(
			 'status'=>0,
			 );
	        $this->db->where('id', $data[$i]);
	        $this->db->update('amspeimage',$postdata);
        }
	}
public function getamspeimage($id) {
		$condition = "id =" . "'" . $id . "'";
		$this->db->select('*');
		$this->db->from('amspeimage');
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 1) {
		return $query->row();
		} else {
		return false;
		}
	}
public function getamspeimages() {
		$this->db->select('*');
		$this->db->from('amspeimage');
		$query = $this->db->get();
		return $query->result();
	}
	
	
		public function getlistamenitiesnspecifications() {
		$this->db->select('*');
		$this->db->from('schoollavel');
		$query = $this->db->get();
		return $query->result();
	}
	
	
	
	
}
?>
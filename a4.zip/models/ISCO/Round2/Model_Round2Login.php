<?php
class Model_Round2Login extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function checkLogin($data)
    {
        $query = $this->db->select('*')->from('student')->where(array(
            'username' => $data['username'],
            'password' => md5($data['password']),
            'status' => 1
        ))->limit(1)->get();
        if ($query->num_rows())
            return true;
        else
            return false;
    }

    public function getStudentDetails($username)
    {
        $query = $this->db->select('*')->from('student')->where('username', $username)->limit(1)->get();
        if ($query->num_rows())
            return $query->row();
        else
            return false;
    }
}
<?php

class Model_studymaterials extends CI_Model {


    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


public function getproductcategory($category_id) {
        $condition = "amspeimage_id ='" . $category_id . "'";
        $this->db->select('amspeimage.*');
        $this->db->from('amspeimage');        
        $this->db->where($condition);        
        $query = $this->db->get();        
        return $query->result();
    }






public function getallcategoriess() {
		
		$this->db->select('*');		
		
		$this->db->from('schoollavel');
		
		$query = $this->db->get();		
		return $query->result();
	}
	




}

?>
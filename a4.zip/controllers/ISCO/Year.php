<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Year extends CI_Controller
{
    public function index($year)
    {
        if($year==2017 || $year==2018 || $year==2019 )
             $this->load->view('ISCO/'.$year);
        else
            show_404();
    }
}
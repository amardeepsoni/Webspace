<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function index() {
        if(!$this->session->userdata('round2_login')['username']){
            redirect(round2path.'/login');
        }
        $data = array(
            'username' => $_SESSION['round2_login']['username'],
         );
        $this->load->view(round2path.'/dashboard',$data);
    }

}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Instructions extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model(round2path . '/Model_Round2');
    }
    public function Quiz1() {
        if(!$this->session->userdata('round2_login')['username']){
            redirect(round2path.'/login');
        }
        $quizDetails = $this->Model_Round2->getQuizDetails($_SESSION['round2_login']['level'],1);
        if($quizDetails) {
            $data = array(
                'quizDetails' => $quizDetails
            );
            if ($this->Model_Round2->checkUser($_SESSION['round2_login']['username'], $quizDetails->quizid))
                $this->load->view(round2path.'/submitQuiz');
            else
                $this->load->view(round2path.'/instructionsQuiz1',$data);
        }
        else {
            $this->load->view('errors/wrong.php');
        }
    }


    public function Quiz2() {
        if(!$this->session->userdata('round2_login')['username']){
            redirect(round2path.'/login');
        }
        $quizDetails = $this->Model_Round2->getQuizDetails($_SESSION['round2_login']['level'],2);
        if($quizDetails) {
            $data = array(
                'quizDetails' => $quizDetails
            );
            $this->load->view(round2path.'/instructionsQuiz2',$data);
        }
        else {
            $this->load->view('errors/wrong.php');
        }
    }
    public function Quiz3() {
        if(!$this->session->userdata('round2_login')['username']){
            redirect(round2path.'/login');
        }
        $quizDetails = $this->Model_Round2->getQuizDetails($_SESSION['round2_login']['level'],3);
        if($quizDetails) {
            $data = array(
                'quizDetails' => $quizDetails
            );
            $this->load->view(round2path.'/instructionsQuiz3',$data);
        }
        else {
            $this->load->view('errors/wrong.php');
        }
    }
    public function Quiz4() {
        if(!$this->session->userdata('round2_login')['username']){
            redirect(round2path.'/login');
        }
        $quizDetails = $this->Model_Round2->getQuizDetails($_SESSION['round2_login']['level'],4);
        if($quizDetails) {
            $data = array(
                'quizDetails' => $quizDetails
            );
            $this->load->view(round2path.'/instructionsQuiz4',$data);
        }
        else {
            $this->load->view('errors/wrong.php');
        }
    }
    public function Quiz5() {
        if(!$this->session->userdata('round2_login')['username']){
            redirect(round2path.'/login');
        }
        $quizDetails = $this->Model_Round2->getQuizDetails($_SESSION['round2_login']['level'],5);
        if($quizDetails) {
            $data = array(
                'quizDetails' => $quizDetails
            );
            $this->load->view(round2path.'/instructionsQuiz5',$data);
        }
        else {
            $this->load->view('errors/wrong.php');
        }
    }

    public function checkQuizStatus ($skill_id) {
        if(!$this->session->userdata('round2_login')['username']){
            redirect(round2path.'/login');
        }
        $quizDetails = $this->Model_Round2->getQuizDetails($_SESSION['round2_login']['level'],$skill_id);
        if($quizDetails) {
            if ($quizDetails->status)
            {
                echo $_GET["callback"] . "(".json_encode( 1 ). ");";
            }
        }
        else
            echo $_GET["callback"] . "(".json_encode( 0 ). ");";
    }

}
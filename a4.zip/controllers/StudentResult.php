<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StudentResult extends CI_Controller
{
    public function index()
    {
        // Redirect if a user not logged in
        if (!$this->session->userdata('studentlogged_in')['id']) {
            redirect('login');
        }
        $this->load->model('student_model');
        $data=array();
        $data['page_title'] = "Result";
        $data['studentinfo'] = $this->student_model->read_by_reg_no($_SESSION['studentlogged_in']['username']);
//        print_r($data['studentinfo']);
        $this->load->view('accountstudentheader',$data);
        $this->load->view('student_result',$data);
        $this->load->view('accountfooter');
    }
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GenerateRound1Results extends CI_Controller {

    public function index()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(adminpath . '/login');
        }
        $ch = curl_init('https://intellifyflask-api.ap-south-1.elasticbeanstalk.com/api/SetQualifications');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        $status = curl_getinfo($ch);
        redirect(base_url().adminpath.'/Dashboard');
    }
}

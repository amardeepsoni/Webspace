<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StudentRegistration extends CI_Controller
{
    public function index()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(adminpath . '/login');
        }

        $this->load->view(adminpath.'/header');
        $this->load->view(adminpath.'/studentRegistration');
        $this->load->view(adminpath.'/footer');
    }
}
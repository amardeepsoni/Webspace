<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Studymaterial extends CI_Controller {

	public function index()
	{
		if (!$this->session->userdata('logged_in')) {
            redirect(adminpath.'/login');
        }

        $data=array();
        $data['breadcrumbs'][] = array(
		'text' => 'Home',
		'href' => '#'
		);
				
		$data['breadcrumbs'][] = array(
		'text' => 'Study Materials Manager',
		'href' => base_url().adminpath.'/studymaterial'
		);
		$data['heading']="Study Materials Manager";
		$this->load->model(adminpath.'/model_studymaterial');
		$data['allamspeimages']= array();	

		$data['allamspeimages']= array();	
    	$results = $this->model_studymaterial->getamspeimages();
		if ($results) {  
			foreach($results as $val){
				if($val->image) {	
					$thumbimage=resizeimage($val->image,100,80);
					$image = "<img src='".$thumbimage."' title='".$val->name."'/>";
				}
				else {
					$thumbimage=resizeimage('no_image.jpg',100,80);
					$image = "<img src='".$thumbimage."' title='".$val->name."'/>";
				}
				$data['allamspeimages'][] = array(
					'id' => $val->id,
					'name' => $val->name,
					'image' => $image,
					'status' => $val->status,
					'href' => base_url().adminpath.'/studymaterial/edit?id=' . $val->id
				);
			}
		}
		
		$data['deleteaction'] = base_url().adminpath.'/studymaterial/delete';
		$data['activeaction'] = base_url().adminpath.'/studymaterial/active';
		$data['inactiveaction'] = base_url().adminpath.'/studymaterial/inactive';
		$this->load->view(adminpath.'/header');
		$this->load->view(adminpath.'/studymaterial',$data);
		$this->load->view(adminpath.'/footer');

    }
    public function active(){

		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$this->load->model(adminpath.'/model_studymaterial');
			$this->model_studymaterial->active($_POST['table_records']);
    	}
    	redirect(adminpath.'/studymaterial');
    }
    public function inactive(){

		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$this->load->model(adminpath.'/model_studymaterial');
			$this->model_studymaterial->inactive($_POST['table_records']);
    	}
    	redirect(adminpath.'/studymaterial');
    }
    public function delete(){

		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$this->load->model(adminpath.'/model_studymaterial');
			$this->model_studymaterial->delete($_POST['table_records']);
    	}
    	redirect(adminpath.'/studymaterial');
    }
    public function add() {
        
		 if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$this->load->model(adminpath.'/model_studymaterial');
			$postdata = array();
			if($_FILES['image']['name'] <>'')
		 	{
				$allowed_filetypes = array('.pdf','.doc','.docx','.gif','.jpg','.jpeg','.png');			
				$expdoc_file=$_FILES['image']['name'];
				$expdoc_file = str_replace('','-',$expdoc_file);
				$ext = substr($expdoc_file, strpos($expdoc_file,'.'), strlen($expdoc_file)-1);
				if(!in_array($ext,$allowed_filetypes))
					die('The file you attempted to upload is not allowed.');
				$random_digit=rand(0000,9999);
				$expdoc_file=$random_digit.$expdoc_file;
				move_uploaded_file($_FILES['image']['tmp_name'], DIR_IMAGE."image/".$expdoc_file) or $error = "Not Uploaded";
				$imgname="image/".$expdoc_file;
				$postdata['image'] =$imgname;
			 }
			$category = $this->input->post('category');
			$postdata['name'] = $this->input->post('name');
			$postdata['home'] = $this->input->post('home');
			$postdata['amspeimage_id'] = $this->input->post('amspeimage_id');
			$postdata['date_added'] = date('Y-m-d H:i:s');
			$postdata['status'] = '1';
			$this->model_studymaterial->add($postdata,$category);
			$this->session->set_flashdata('imagenotify', 'Username and Password not Valid.');
			redirect(adminpath.'/studymaterial');
		}
		$this->getform();
		
    }	
     public function edit() {
        
		 if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$this->load->model(adminpath.'/model_studymaterial');
			$postdata = array();
			if($_FILES['image']['name'] <>'')
		 	{
				$allowed_filetypes = array('.pdf','.doc','.docx','.gif','.jpg','.jpeg','.png');			
				$expdoc_file=$_FILES['image']['name'];
				$expdoc_file = str_replace('','-',$expdoc_file);
				$ext = substr($expdoc_file, strpos($expdoc_file,'.'), strlen($expdoc_file)-1);
				if(!in_array($ext,$allowed_filetypes))
					die('The file you attempted to upload is not allowed.');
				$random_digit=rand(0000,9999);
				$expdoc_file=$random_digit.$expdoc_file;
				move_uploaded_file($_FILES['image']['tmp_name'], DIR_IMAGE."image/".$expdoc_file) or $error = "Not Uploaded";
				$imgname="image/".$expdoc_file;
				$postdata['image'] =$imgname;
			 }
			$category = $this->input->post('category');
			$postdata['name'] = $this->input->post('name');
			$postdata['home'] = $this->input->post('home');
			$postdata['amspeimage_id'] = $this->input->post('amspeimage_id');
			$postdata['date_modify'] = date('Y-m-d H:i:s');
			$postdata['status'] = '1';
			$this->model_studymaterial->edit($this->input->get('id'),$postdata,$category);
			$this->session->set_flashdata('imagenotify', 'Username and Password not Valid.');
			redirect(adminpath.'/studymaterial');
		}
		$this->getform();
		
    }	
    public function getform() {
		
		$this->load->model(adminpath.'/model_studymaterial');
		$this->load->model(adminpath.'/model_category');
			
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
		'text' => 'Home',
		'href' => '#'
		);
				
		$data['breadcrumbs'][] = array(
		'text' => 'Study Materials Manager',
		'href' => base_url().adminpath.'/studymaterial'
		);
				
		if (!$this->input->get('id')) {
		$data['breadcrumbs'][] = array(
		'text' => 'Add Study Materials',
		'href' => '#'
		);
		$data['heading']="Add Study Materials";
		$data['action'] = base_url().adminpath.'/studymaterial/add';
		} else {
		$data['breadcrumbs'][] = array(
		'text' => 'Edit Image',
		'href' => '#'
		);
		$data['heading']="Edit Study Materials";
		$data['action'] = base_url().adminpath.'/studymaterial/edit?id=' . $this->input->get('id');
		}
		
		if ($this->input->get('id') && $this->input->server('REQUEST_METHOD') != 'POST') {
      		$info = $this->model_studymaterial->getamspeimage($this->input->get('id'));
    	}
		
				if ($this->input->post('home')) {
      		$data['home'] = $this->input->post('home');
    	} elseif (isset($info)) {
			$data['home'] = $info->home;
		} else {
      		$data['home'] = '';
    	}
		
		

		if ($this->input->post('name')) {
      		$data['name'] = $this->input->post('name');
    	} elseif (isset($info)) {
			$data['name'] = $info->name;
		} else {
      		$data['name'] = '';
    	}
		
			if ($this->input->post('amspeimage_id')) {
      		$data['amspeimage_id'] = $this->input->post('amspeimage_id');
    	} elseif (isset($info)) {
			$data['amspeimage_id'] = $info->amspeimage_id;
		} else {
      		$data['amspeimage_id'] = '';
    	}
		


    	if ($this->input->post('id')) {
      		$data['id'] = $this->input->post('id');
    	} elseif (isset($info)) {
			$data['id'] = $info->id;
		} else {
      		$data['id'] = '0';
    	}

    	
				
				
				
		if (isset($info)) {
    if($info->image) {	
					$data['image'] = "<a href='".base_url()."uploads/".$info->image."' target='_blank'>Click Here </a>";
				}
	else {
					$data['image'] = "";
				}
    	}
    	else {
				$data['image'] = "";
		}
		
				
				
				
				
				
				
				
				
				
				
		$data['cancel'] = base_url().adminpath.'/image';
		
		
		
		$this->load->model(adminpath.'/model_amenitiesnspecification');
		
		
		
			$data['listamenitiesnspecifications']= array();	
    	$results = $this->model_studymaterial->getlistamenitiesnspecifications();
		if ($results) {  
			foreach($results as $val){
			
				$data['listamenitiesnspecifications'][] = array(
					'id' => $val->id,
					'name' => $val->name
					
				);
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		$this->load->view(adminpath.'/header');
		$this->load->view(adminpath.'/studymaterialform',$data);
		$this->load->view(adminpath.'/footer');
				
	}
}
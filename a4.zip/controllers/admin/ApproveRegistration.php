<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ApproveRegistration extends CI_Controller {

    public function index()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(adminpath . '/login');
        }
        $this->load->model(adminpath.'/model_school');
        $data['schools'] = $this->model_school->getAllSchools();
        $data['heading'] = "Approve Registration";
        $this->load->view(adminpath . '/header');
        $this->load->view(adminpath.'/ApproveRegistration',$data);
        $this->load->view(adminpath . '/footer');
    }

    public function approveAll ($id) {
        if (!$this->session->userdata('logged_in')) {
            redirect(adminpath . '/login');
        }
        $this->load->model(adminpath.'/model_student');
        $this->model_student->approveAllStudents($id);
        redirect(base_url().adminpath.'/ApproveRegistration');
    }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UploadController extends CI_Controller {

    function __construct()
    {
        parent::__construct();

      //  exec('pip3 install pandas');
    }

    private function runScript($csvPath) {
         $o = shell_exec('python3 -W ignore scripts/result_analysis.py '.$csvPath.' 2>&1');
        if($o)
         print_r($o) ;
        else echo "no $0";
    }

    private function runQuesScript($csvPath , $qtype , $quizid) {
        $o = shell_exec('python3 scripts/question_upload.py '.$csvPath.' '.$qtype.' '.$quizid.' 2>&1');
//        return $o;
        if($o)
            print_r($o) ;
        else echo "no $0";
    }

    public function index()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(adminpath.'/login');
        }
        $data['error'] = '';
        $data['success'] = '';
        $this->load->view(adminpath.'/header');
        $this->load->view(adminpath.'/uploadCSV',$data);
        $this->load->view(adminpath.'/footer');
    }

    public function uploadData() {
        $this->load->library('S3');
//        print_r($_FILES);
//        print_r($this->input->post('user_file'));
            $fileName = time().'_'.$_FILES['user_file']['name'];
            $fileTempName = $_FILES['user_file']['tmp_name'];
            if ($this->s3->putObjectFile($fileTempName, "codepipeline-ap-south-1-323045938757", 'Intellify_CSV/Round1/'.$fileName, S3::ACL_PRIVATE)) {
                    $data['error'] = '';
                    $data['success'] = "Uploaded Successfully";
                    $this->runScript($fileTempName);
                    //$this->load->view(adminpath.'/uploadCSV',$data);
            }
            else {
                $data['success'] = '';
                $data['error'] = "Unable to upload file";
                $this->load->view(adminpath.'/uploadCSV', $data);
            }
    }

    public function uploadQuesData() {
        $this->load->library('S3');
        $fileName = time().'_'.$_FILES['user_file']['name'];
        $fileTempName = $_FILES['user_file']['tmp_name'];
        if ($this->s3->putObjectFile($fileTempName, "codepipeline-ap-south-1-323045938757", 'Intellify_CSV/Questions/'.$fileName, S3::ACL_PRIVATE)) {
            $this->runQuesScript($fileTempName, $this->input->post('qtype'), $this->input->post('quizid'));
           // redirect(adminpath.'/AllExams');
            $questionData = array(
                'quizid' => $this->input->post('quizid'),
                'mcq2' => 0,
                'mcq4' => 0,
                'integer' => 0,
                'success' => "",
                'error' => "",
                'action' => base_url() . adminpath . '/AddExam/submitQuestions'
            );
//            $this->load->view(adminpath . '/header');
//            $this->load->view(adminpath . '/addExamQuestions.php', $questionData);
//            $this->load->view(adminpath . '/footer');
        }
        else
        {
            $data['success'] = '';
            $data['error'] = $this->upload->display_errors();
            //Make error page to display all errors
            //$this->load->view(adminpath.'/addExamQuestions', $data);
        }
    }
}

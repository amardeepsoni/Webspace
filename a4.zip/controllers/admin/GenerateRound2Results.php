<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GenerateRound2Results extends CI_Controller {

    public function index()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(adminpath . '/login');
        }
        $ch = curl_init('https://intellifyflask-api.ap-south-1.elasticbeanstalk.com/api/SetHistory');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        $status = curl_getinfo($ch);
//        echo json_encode($status, JSON_PRETTY_PRINT);
//        print_r($response);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpcode == 200) {
            $ch1 = curl_init('https://intellifyflask-api.ap-south-1.elasticbeanstalk.com/api/SetPerformance');
            curl_setopt($ch1, CURLOPT_POST, 1);
            curl_setopt($ch1, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch1, CURLOPT_HEADER, 0);
            curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch1, CURLOPT_SSL_VERIFYHOST, false);
            $response = curl_exec($ch1);
            $status = curl_getinfo($ch1);
//            echo json_encode($status, JSON_PRETTY_PRINT);
//            print_r($response);
        }
        redirect(base_url().adminpath.'/Dashboard');
    }
}

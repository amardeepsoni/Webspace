<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Editpassword extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        
        $this->load->model(array(           
            'student_model'
        ));  
    } 
 
    //all post details without slider
    public function index($id = null)
    { 
         if(!$this->session->userdata('studentlogged_in')['id']){ 
            redirect('login');
        }
       
        $data=array();


        $data['page_title'] = 'Edit Password';
        $data['meta_keyword'] = 'Edit Password';
        $data['meta_description'] = 'Edit Password';

        $data['breadcrumbs'][] = array(
        'text' => 'Home',
        'href' => base_url()
        );
                
        $data['breadcrumbs'][] = array(
        'text' => 'Edit Password',
        'href' => base_url('editpassword')
        );
		   
        $data['studentinfo'] = $this->student_model->studentinfo(($this->session->userdata('studentlogged_in')['username']));


        $data['action'] = base_url('editpassword/update');
        $this->load->view('accountstudentheader',$data);
        $this->load->view('editpassword',$data);
        $this->load->view('accountfooter');
    } 


    public function update()
    {


        $data['testimonial'] = (object)$postData = [
            'id'      => $this->input->post('id',true),
            'password'    => md5($this->input->post('password',true)),
            'mpassword'    => $this->input->post('password',true),
        ]; 

        if ($this->student_model->passwordupdate($postData)) {
                    #set success message
            $this->session->set_flashdata('passwordmsg','Change Successfully');
        } else {
                    #set exception message
            $this->session->set_flashdata('exception', display('please_try_again'));
        }

        
        $data['studentinfo'] = $this->student_model->studentinfo(($this->session->userdata('studentlogged_in')['email']));
        
        redirect('editpassword');
    }



}

